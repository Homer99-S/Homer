@echo off
cd /d "%~dp0"
start "" pythonw.exe bootstrap.py
