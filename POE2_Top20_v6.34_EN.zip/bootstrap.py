import os
import subprocess
import sys

APP = os.path.dirname(os.path.abspath(__file__))
UPDATER = os.path.join(APP, "updater.py")
PYTHONW = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
PYTHON = PYTHONW if os.path.exists(PYTHONW) else sys.executable

subprocess.run([PYTHON, UPDATER], cwd=APP, creationflags=0x08000000)
