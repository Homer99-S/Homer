import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from datetime import datetime

APP = os.path.dirname(os.path.abspath(__file__))
LOCAL_VERSION_FILE = os.path.join(APP, "version.json")
LOG_FILE = os.path.join(APP, "update.log")

VERSION_URL = "https://raw.githubusercontent.com/Homer99-S/Homer/main/version.json"
GITHUB_RAW_BASE = "https://raw.githubusercontent.com/Homer99-S/Homer/main/"

def log(message):
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    print(line, flush=True)

def read_local_version():
    try:
        with open(LOCAL_VERSION_FILE, encoding="utf-8") as f:
            return str(json.load(f).get("version", "0"))
    except Exception as exc:
        log(f"Lokale version.json konnte nicht gelesen werden: {exc}")
        return "0"

def version_tuple(value):
    try:
        return tuple(int(x) for x in str(value).strip().lstrip("v").split("."))
    except Exception:
        return (0,)

def get_remote_info():
    req = urllib.request.Request(VERSION_URL, headers={"User-Agent": "PoE2-Top20-Updater"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))

def download_file(url, target):
    log(f"Lade: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "PoE2-Top20-Updater"})
    with urllib.request.urlopen(req, timeout=60) as r, open(target, "wb") as f:
        shutil.copyfileobj(r, f)

def update_from_zip(package_url, remote_version):
    with tempfile.TemporaryDirectory(prefix="poe2_update_") as tmp:
        zip_path = os.path.join(tmp, "update.zip")
        extract_dir = os.path.join(tmp, "extract")
        os.makedirs(extract_dir)

        download_file(package_url, zip_path)
        with zipfile.ZipFile(zip_path) as z:
            if z.testzip():
                raise RuntimeError("ZIP-Prüfung fehlgeschlagen")
            z.extractall(extract_dir)

        replaced = 0
        for root, dirs, files in os.walk(extract_dir):
            rel_root = os.path.relpath(root, extract_dir)
            dest_root = APP if rel_root == "." else os.path.join(APP, rel_root)
            os.makedirs(dest_root, exist_ok=True)
            for filename in files:
                src = os.path.join(root, filename)
                dst = os.path.join(dest_root, filename)
                os.replace(src, dst)
                replaced += 1

        log(f"Update auf {remote_version} abgeschlossen: {replaced} Dateien ersetzt.")
        log("Der Updater selbst wurde ebenfalls aktualisiert.")

def main():
    log("========== Updater-Start ==========")
    local = read_local_version()
    log(f"Lokale Version: {local}")

    try:
        remote = get_remote_info()
        remote_version = str(remote.get("version", "0"))
        package = str(remote.get("package", "")).strip()
        log(f"GitHub-Version: {remote_version}")

        if version_tuple(remote_version) <= version_tuple(local):
            log("Keine Aktualisierung erforderlich.")
        elif not package:
            log("FEHLER: Kein Update-Paket angegeben.")
        else:
            log(f"Neue Version erkannt: {local} -> {remote_version}")
            update_from_zip(GITHUB_RAW_BASE + package, remote_version)
    except Exception as exc:
        log(f"UPDATE-FEHLER: {type(exc).__name__}: {exc}")
        log("Vorhandene lokale Version wird unverändert gestartet.")

    overlay = os.path.join(APP, "overlay.py")
    log(f"Starte Overlay: {overlay}")
    try:
        subprocess.Popen([sys.executable, overlay], cwd=APP)
        log("Overlay wurde gestartet.")
    except Exception as exc:
        log(f"FEHLER beim Overlay-Start: {type(exc).__name__}: {exc}")
    log("========== Updater-Ende ==========")

if __name__ == "__main__":
    main()
