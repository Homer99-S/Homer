import os
import subprocess
import sys

APP = os.path.dirname(os.path.abspath(__file__))
UPDATER = os.path.join(APP, "updater.py")

subprocess.run([sys.executable, UPDATER], cwd=APP)
