PoE2 Top20 v6.26

This version separates item recognition improvements from quantity OCR.

Recognition changes:
- Standard Rune families are now supported only by references from the SAME Rune family.
- Lesser/Normal/Greater/Perfect family detection is derived from the current poe.ninja reference set.
- Special one-stage Runes remain special and are not promoted just because their name contains Greater.
- Confirmed absent items remain blocked: Emergent Possibility and Astrid's Creativity.

Clipboard:
- COPY 2 SCREENSHOTS creates one combined image containing the complete stash and debug screenshots.
- COPY STASH copies only the stash screenshot as a real image.
- COPY DEBUG copies only the debug screenshot as a real image.
- COPY REPORT copies the text report.

The quantity/OCR logic was deliberately not changed in this version.
