import tkinter as tk
from tkinter import messagebox
from PIL import ImageGrab, Image, ImageTk, ImageDraw, ImageEnhance, ImageOps, ImageFilter
import ctypes, ctypes.wintypes as wintypes

# Hide the launcher CMD window after the GUI starts. The app itself remains
# visible and usable; this also keeps the PoE2 stash unobstructed.
try:
    _console_hwnd = ctypes.windll.kernel32.GetConsoleWindow()
    if _console_hwnd:
        ctypes.windll.user32.ShowWindow(_console_hwnd, 0)
except Exception:
    pass
import numpy as np
import os, json, time, urllib.request, urllib.parse, hashlib, io, math

APP=os.path.dirname(os.path.abspath(__file__))
SHOT_DIR=os.path.join(APP,"screenshots")
SLOT_DIR=os.path.join(APP,"slots")
QTY_DEBUG_DIR=os.path.join(APP,"quantity_debug")
CONFIG=os.path.join(APP,"config.json")
DIAG_LOG=os.path.join(APP,"diagnostics_latest.txt")

# The program is often installed on a OneDrive Desktop. Reference icons and
# generated cache/debug JSON are high-churn files and should not be synced or
# locked by OneDrive while the matcher is using them.
LOCAL_ROOT=os.environ.get("LOCALAPPDATA") or APP
DATA_DIR=os.path.join(LOCAL_ROOT,"PoE2Top20")
REF_JSON=os.path.join(DATA_DIR,"general_items.json")
REF_DIR=os.path.join(DATA_DIR,"reference_icons")
LOCAL_CHARM_REF_DIR=os.path.join(APP,"special_refs","charms")
LOCAL_STASH_SEED_DIR=os.path.join(APP,"special_refs","stash_samples")
LOCAL_STASH_SEED_MANIFEST=os.path.join(LOCAL_STASH_SEED_DIR,"manifest.json")
API_DEBUG=os.path.join(DATA_DIR,"api_debug.json")
ICON_DEBUG=os.path.join(DATA_DIR,"icon_download_debug.json")
VISUAL_ATLAS_DIR=os.path.join(DATA_DIR,"visual_atlas")
VISUAL_ATLAS_JSON=os.path.join(VISUAL_ATLAS_DIR,"atlas.json")
VISUAL_ATLAS_VERSION="v6.20"
os.makedirs(VISUAL_ATLAS_DIR,exist_ok=True)

LEAGUE="Runes of Aldur"

# Current-stash negative references confirmed by the user. These are NOT
# treated as generic exclusions forever: the list lives in a small editable
# file next to the program, so a future scan can re-enable an item simply by
# removing it from confirmed_absent.json if it is ever acquired.
CONFIRMED_ABSENT_FILE=os.path.join(APP,"confirmed_absent.json")
DEFAULT_CONFIRMED_ABSENT=[
    "Emergent Possibility",
    "Astrid's Creativity",
]

def load_confirmed_absent_names():
    try:
        with open(CONFIRMED_ABSENT_FILE,encoding="utf-8") as f:
            data=json.load(f)
        if isinstance(data,list):
            return {str(x).strip() for x in data if str(x).strip()}
    except Exception:
        pass
    return set(DEFAULT_CONFIRMED_ABSENT)

CONFIRMED_ABSENT_NAMES=load_confirmed_absent_names()
CHARM_REF_VERSION="v5.98"
GENERAL_TYPES=[
    "Currency","Fragments","Abyss","UncutGems","LineageSupportGems",
    "Essences","SoulCores","Idols","Runes","UniqueCharms","Ritual","Expedition",
    "Delirium","Breach","Verisium"
]

# PoE2 normal/magic charms are base items rather than economy entries.
# poe.ninja's UniqueCharms endpoint therefore cannot cover them. The base
# icons are stable game CDN assets and are used only as visual references.
BASE_CHARM_REFS=[
    ("Ruby Charm", "RubyCharm"),
    ("Sapphire Charm", "SapphireCharm"),
    ("Topaz Charm", "TopazCharm"),
    ("Stone Charm", "StoneCharm"),
    ("Silver Charm", "SilverCharm"),
    ("Thawing Charm", "ThawingCharm"),
    ("Staunching Charm", "StaunchingCharm"),
    ("Antidote Charm", "AntidoteCharm"),
    ("Dousing Charm", "DousingCharm"),
    ("Grounding Charm", "GroundingCharm"),
    ("Amethyst Charm", "AmethystCharm"),
    ("Golden Charm", "GoldenCharm"),
]

def matcher_family(item_type):
    t=str(item_type or "").strip()
    if t in ("Charms", "UniqueCharms"):
        return "Charms"
    return t

# Populated from the actual poe.ninja Runes reference set.  A name is
# considered tiered only when poe.ninja contains the complete Lesser/Normal/Greater
# triplet.  This deliberately handles special cases such as:
#   Greater Rune of Leadership -> special (no matching Lesser/Normal pair)
#   Warding Rune of Equinox    -> special (single item)
#   Rune of Reach              -> special (single item)
#   purple one-stage runes     -> special (single item)
_RUNE_TIER_MAP={}
_RUNE_FAMILY_MAP={}


def _rune_base_name(name):
    """Return the canonical base name for a tiered Rune family."""
    n=str(name or "").strip()
    for prefix in ("Lesser ", "Greater ", "Perfect "):
        if n.startswith(prefix):
            return n[len(prefix):]
    return n


def build_rune_tier_map(refs):
    """Build Rune tier/family information from the poe.ninja reference set.

    Important: a tier is NOT inferred from the word ``Greater`` alone.
    We first detect complete upgrade families in the live reference set.
    Current PoE2 can have 3-stage and 4-stage families; both are supported.
    Anything without a real upgrade family remains ``special``.  This keeps
    special one-stage items such as Greater Rune of Leadership and Warding
    Rune of Equinox separate from normal tiered Rune families.
    """
    global _RUNE_TIER_MAP, _RUNE_FAMILY_MAP
    names={str(r.get("name","" )).strip() for r in refs
           if str(r.get("type","" )).strip()=="Runes"}

    families={}
    for n in names:
        base=_rune_base_name(n)
        if base.endswith(" Rune"):
            families.setdefault(base,set()).add(n)

    out={}
    fmap={}
    for base, members in families.items():
        lesser="Lesser "+base
        normal=base
        greater="Greater "+base
        perfect="Perfect "+base
        stages=[]
        if lesser in names: stages.append(("lesser",lesser))
        if normal in names: stages.append(("normal",normal))
        if greater in names: stages.append(("greater",greater))
        if perfect in names: stages.append(("perfect",perfect))

        # A genuine upgrade family needs at least Lesser + Normal + Greater.
        # Perfect is optional because some league/reference snapshots may not
        # expose the fourth stage yet.
        if {x[0] for x in stages} >= {"lesser","normal","greater"}:
            for tier,n in stages:
                out[n]=tier
                fmap[n]=base

    _RUNE_TIER_MAP=out
    _RUNE_FAMILY_MAP=fmap
    return out


def rune_tier(name):
    """Return the confirmed tier or ``special`` for one-stage Runes."""
    return _RUNE_TIER_MAP.get(str(name or "").strip(), "special")


def rune_family(name):
    """Return the confirmed upgrade family or the item itself if special."""
    n=str(name or "").strip()
    return _RUNE_FAMILY_MAP.get(n, n)


def is_standard_rune(name):
    return rune_tier(name) in ("lesser", "normal", "greater", "perfect")

os.makedirs(SHOT_DIR,exist_ok=True); os.makedirs(SLOT_DIR,exist_ok=True); os.makedirs(QTY_DEBUG_DIR,exist_ok=True); os.makedirs(DATA_DIR,exist_ok=True); os.makedirs(REF_DIR,exist_ok=True)

u=ctypes.windll.user32
VK_F7=0x76; VK_F8=0x77

class RECT(ctypes.Structure):
    _fields_=[("left",ctypes.c_long),("top",ctypes.c_long),
              ("right",ctypes.c_long),("bottom",ctypes.c_long)]

# 5x7 digit templates. We compare normalized white-pixel patterns.
FONT={
"0":["01110","10001","10011","10101","11001","10001","01110"],
"1":["00100","01100","00100","00100","00100","00100","01110"],
"2":["01110","10001","00001","00010","00100","01000","11111"],
"3":["11110","00001","00001","01110","00001","00001","11110"],
"4":["00010","00110","01010","10010","11111","00010","00010"],
"5":["11111","10000","10000","11110","00001","00001","11110"],
"6":["01110","10000","10000","11110","10001","10001","01110"],
"7":["11111","00001","00010","00100","01000","01000","01000"],
"8":["01110","10001","10001","01110","10001","10001","01110"],
"9":["01110","10001","10001","01111","00001","00001","01110"],
}

class LogText(tk.Text):
    LOG_FILE=None
    """Text log that keeps each program message on its own logical line.

    Unlike Listbox, Text can wrap long diagnostics onto subsequent visual
    lines, so information that exceeds the available width remains readable.
    """
    def insert(self, index, chars, *args):
        chars=str(chars)
        if index == "end" and chars and not chars.endswith("\n"):
            chars += "\n"
        # v6.17: persist the complete logical log independently of the GUI
        # scroll position. This is the key diagnostic artifact for the next
        # matching step; the user can simply attach this TXT after F8.
        try:
            if index == "end" and self.LOG_FILE and chars:
                with open(self.LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(chars)
        except Exception:
            pass
        return super().insert(index, chars, *args)


class App:
    def __init__(self):
        self.root=tk.Tk()
        self.root.title("PoE2 Top20 – v6.29")
        # Keep the capture layout on the right half so the PoE2 stash remains
        # visible on the left. Width stays fixed; height is resizable so the
        # complete diagnostic log can be reached on smaller screens/taskbars.
        sw=self.root.winfo_screenwidth()
        sh=self.root.winfo_screenheight()
        rw=sw//2
        rh=max(650, sh-45)
        self.root.geometry(f"{rw}x{rh}+{sw-rw}+0")
        self.root.minsize(rw,520)
        self.root.resizable(False,True)
        self.root.attributes("-topmost",True)

        self.old={VK_F7:False,VK_F8:False}
        self.key_armed={VK_F7:True,VK_F8:True}
        self.scan_running=False
        self.evaluation_id=time.strftime("%Y%m%d-%H%M%S")
        self.f8_count=0
        self.cfg=self.load_config(); self.cleanup_scan_output(); self.counter=1
        self.cal_window=None; self.cal_points=[]; self.cal_image=None
        self.session_items={}
        self.session_hashes=set()
        self._qty_debug_count=0
        # v6.29: remember the two latest scan images so they can be copied
        # together to the Windows clipboard for easy Ctrl+V upload.
        self.last_stash_path=None
        self.last_debug_path=None
        self.session_tab_count=0
        self.league_id=None
        self.league_name=None

        tk.Label(self.root,text="POE2 TOP 20 – v6.29",
                 font=("Segoe UI",16,"bold")).pack(pady=9)
        tk.Label(
            self.root,
            text="Multi-Stash Scan – F8 per tab, results as Top 20.",
            wraplength=rw-24).pack(padx=12)

        row=tk.Frame(self.root); row.pack(pady=8)
        tk.Button(row,text="CALIBRATE (F7)",command=self.start_calibration,
                  width=18,height=2).pack(side="left",padx=4)
        tk.Button(row,text="SCAN (F8)",command=self.capture,
                  width=18,height=2).pack(side="left",padx=4)
        tk.Button(row,text="OPEN CONFIG",command=self.open_config,
                  width=18,height=2).pack(side="left",padx=4)
        tk.Button(row,text="NEW EVALUATION",command=self.reset_session,
                  width=18,height=2).pack(side="left",padx=4)

        copy_row=tk.Frame(self.root); copy_row.pack(pady=(0,6))
        tk.Button(copy_row,text="COPY 2 SCREENSHOTS",
                  command=self.copy_two_screenshots, width=24,height=2).pack(side="left",padx=4)
        tk.Button(copy_row,text="COPY REPORT TEXT",
                  command=self.copy_report, width=24,height=2).pack(side="left",padx=4)

        self.status=tk.StringVar(
            value="Press F7 once → press F8 for each tab.")
        self.log_cache_path=DATA_DIR
        tk.Label(self.root,textvariable=self.status,
                 wraplength=rw-24).pack(padx=12,pady=5)

        # Only the result area and log are resizable. The controls above remain
        # fixed and visible.
        self.main_pane=tk.PanedWindow(
            self.root,orient="vertical",sashrelief="raised",sashwidth=10)
        self.main_pane.pack(fill="both",expand=True,padx=8,pady=8)

        self.result_parent=tk.Frame(self.main_pane)
        self.log_parent=tk.LabelFrame(
            self.main_pane,text="Log — drag the divider",
            font=("Segoe UI",9,"bold"))
        self.main_pane.add(self.result_parent,minsize=220)
        self.main_pane.add(self.log_parent,minsize=120)

        result_wrap=tk.Frame(self.result_parent)
        result_wrap.pack(fill="both",expand=True,padx=4,pady=4)
        self.result_canvas=tk.Canvas(
            result_wrap,highlightthickness=1,background="white")
        # The Top20 area is deliberately sized for all 20 result rows.
        # There is no result scrollbar: the log belongs below the complete list.
        self.result_canvas.pack(side="left",fill="both",expand=True)
        self.result_inner=tk.Frame(
            self.result_canvas,background="white")
        self.result_window=self.result_canvas.create_window(
            (0,0),window=self.result_inner,anchor="nw")
        self.result_inner.bind(
            "<Configure>",
            lambda e:self.result_canvas.configure(
                scrollregion=self.result_canvas.bbox("all")))
        self.result_canvas.bind(
            "<Configure>",
            lambda e:self.result_canvas.itemconfigure(
                self.result_window,width=e.width))
        self.result_images=[]

        tk.Label(
            self.log_parent,
            text="Drag the horizontal divider between results and log to resize.",
            anchor="w",font=("Segoe UI",9)
        ).pack(fill="x",padx=6,pady=4)

        log_frame=tk.Frame(self.log_parent)
        log_frame.pack(fill="both",expand=True)
        LogText.LOG_FILE=DIAG_LOG
        try:
            with open(DIAG_LOG, "w", encoding="utf-8") as f:
                f.write("PROGRAM START v6.29 | persistent diagnostic log\n")
        except Exception:
            pass
        self.log=LogText(
            log_frame,font=("Consolas",9),height=8,wrap="word",
            padx=3,pady=2,undo=False)
        self.log_scroll=tk.Scrollbar(
            log_frame,orient="vertical",command=self.log.yview)
        self.log.configure(yscrollcommand=self.log_scroll.set)
        self.log.pack(side="left",fill="both",expand=True,padx=4,pady=4)
        self.log_scroll.pack(side="right",fill="y",pady=4)
        for _msg in getattr(self,"log_pending",[]):
            self.log.insert("end",_msg)
        self.log_pending=[]

        # v6.29: hard startup diagnostic boundary. Do not inherit any text
        # from a prior process/session; the first visible line identifies this
        # exact process instance.
        self.startup_id=time.strftime("%Y%m%d-%H%M%S") + f"-{os.getpid()}"
        self.log.delete("1.0","end")
        self.log.insert("end", f"PROGRAM START v6.29 | startup={self.startup_id} | log reset | file={DIAG_LOG}")
        self.log.insert("end", "READY v6.29 | no screenshot has been captured by this process yet.")

        # Reserve enough vertical space for the complete Top20 (20 rows),
        # while leaving the remaining space for the diagnostic log.
        self.root.after(120, self.set_initial_split)

        self.root.protocol("WM_DELETE_WINDOW",self.close)
        self.root.after(20,self.poll_keys)
        self.root.mainloop()

    def set_initial_split(self):
        try:
            h=self.main_pane.winfo_height()
            # Header + 20 compact rows + footer. Keep at least 120 px for log.
            desired=min(max(500, h-140), 590)
            self.main_pane.sash_place(0, 0, desired)
        except Exception:
            pass

    def load_config(self):
        cfg={"left":0,"top":0,"right":0,"bottom":0,"cols":12,"rows":12,"calibrated":False}
        try:
            with open(CONFIG,encoding="utf-8") as f: cfg.update(json.load(f))
        except Exception: pass
        return cfg

    def cleanup_scan_output(self):
        """Start with a physically empty screenshot output folder.

        v5.97 deliberately does not reuse old stash_/icons_ files. This makes
        it possible to verify that an image was created by the current F8 press.
        The detailed per-slot captures remain in slots/ for diagnostics.
        """
        try:
            os.makedirs(SHOT_DIR,exist_ok=True)
            removed=0
            for name in os.listdir(SHOT_DIR):
                path=os.path.join(SHOT_DIR,name)
                if os.path.isfile(path) and (name.startswith("stash_") or name.startswith("icons_")) and name.lower().endswith(".png"):
                    try:
                        os.remove(path); removed+=1
                    except OSError as ex:
                        self.log_pending=getattr(self,"log_pending",[])
                        self.log_pending.append(f"SCREEN CLEANUP: could not remove {path}: {ex!r}")
            self.counter=1
            return removed
        except Exception as ex:
            self.log_pending=getattr(self,"log_pending",[])
            self.log_pending.append(f"SCREEN CLEANUP ERROR: {ex!r}")
            return 0

    def next_counter(self):
        # Kept for compatibility with existing config/tools. v5.97 starts each
        # application/evaluation with a clean screenshot folder and capture_001.
        return 1

    def safe_json_dump(self,path,obj,indent=2,quiet=False):
        """Write JSON safely on OneDrive/Windows; never abort a scan for a debug file."""
        last=None
        for attempt in range(3):
            tmp=path+f".tmp_{os.getpid()}_{attempt}"
            try:
                with open(tmp,"w",encoding="utf-8") as f:
                    json.dump(obj,f,indent=indent,ensure_ascii=False)
                try:
                    os.replace(tmp,path)
                except PermissionError:
                    # OneDrive may briefly hold the destination. Remove a stale
                    # destination only if possible, then retry the replace.
                    try: os.remove(path)
                    except Exception: pass
                    os.replace(tmp,path)
                return True
            except Exception as ex:
                last=ex
                try:
                    if os.path.exists(tmp): os.remove(tmp)
                except Exception: pass
                time.sleep(0.35*(attempt+1))
        if not quiet:
            self.log.insert("end",f"JSON write skipped: {os.path.basename(path)} | {last!r}")
        return False

    def log_line(self,text):
        self.log.insert("end",str(text) + "\n")
        try:
            # Keep the log bounded. Text uses line/character indices rather
            # than Listbox item indices. Wrapped visual lines are preserved.
            lines=int(self.log.index("end-1c").split(".")[0])
            if lines>4000:
                self.log.delete("1.0", f"{lines-4000}.0")
            self.log.see("end")
        except Exception:
            pass

    def find_poe(self):
        found=[]; EP=ctypes.WINFUNCTYPE(ctypes.c_bool,wintypes.HWND,wintypes.LPARAM)
        def cb(hwnd,_):
            if not u.IsWindowVisible(hwnd): return True
            b=ctypes.create_unicode_buffer(512); u.GetWindowTextW(hwnd,b,512)
            t=b.value.strip().lower()
            if "path of exile 2" not in t and "poe2" not in t:return True
            r=RECT()
            if u.GetWindowRect(hwnd,ctypes.byref(r)):
                if r.right-r.left>700 and r.bottom-r.top>400:
                    found.append((hwnd,r.left,r.top,r.right,r.bottom))
            return True
        u.EnumWindows(EP(cb),0)
        return max(found,key=lambda x:(x[3]-x[1])*(x[4]-x[2])) if found else None

    def grab(self):
        info=self.find_poe()
        if not info:self.status.set("PoE2-Fenster nicht gefunden.");return None
        hwnd,l,t,r,b=info; cr=RECT()
        if u.GetClientRect(hwnd,ctypes.byref(cr)):
            pt=wintypes.POINT(0,0);u.ClientToScreen(hwnd,ctypes.byref(pt))
            l,t=pt.x,pt.y;r=l+cr.right-cr.left;b=t+cr.bottom-cr.top
        self.root.withdraw();self.root.update();time.sleep(.45)
        try:return ImageGrab.grab(bbox=(l,t,r,b),all_screens=True)
        finally:self.root.deiconify();self.root.attributes("-topmost",True)

    def start_calibration(self):
        img=self.grab()
        if img is None:return
        self.cal_image=img;self.cal_points=[]
        sw=max(900,self.root.winfo_screenwidth()-80);sh=max(650,self.root.winfo_screenheight()-130)
        iw,ih=img.size;s=min(1,sw/iw,sh/ih)
        disp=img.resize((int(iw*s),int(ih*s)),Image.Resampling.LANCZOS)
        win=tk.Toplevel(self.root);self.cal_window=win
        win.title("PoE2 Top20 – Kalibrierung");win.attributes("-topmost",True)
        tk.Label(win,text="OBEN LINKS des ersten Slots → UNTEN RECHTS des letzten Slots\nENTER speichern | ESC abbrechen",font=("Segoe UI",10,"bold")).pack(pady=6)
        c=tk.Canvas(win,width=disp.width,height=disp.height,cursor="crosshair",highlightthickness=0);c.pack()
        ph=ImageTk.PhotoImage(disp);c.create_image(0,0,anchor="nw",image=ph);c.image=ph
        self.cal_canvas=c;self.cal_scale=s
        c.bind("<Button-1>",self.cal_click);win.bind("<Return>",lambda e:self.finish_calibration());win.bind("<Escape>",lambda e:self.cancel_calibration())

    def cal_click(self,e):
        if len(self.cal_points)>=2:return
        self.cal_points.append((e.x,e.y));self.cal_canvas.create_oval(e.x-5,e.y-5,e.x+5,e.y+5,outline="red",width=3)
        if len(self.cal_points)==2:
            x1,y1=self.cal_points[0];x2,y2=self.cal_points[1];self.cal_canvas.create_rectangle(x1,y1,x2,y2,outline="red",width=2)

    def finish_calibration(self):
        if len(self.cal_points)!=2:return
        (a,b),(c,d)=self.cal_points;s=self.cal_scale;x1,y1,x2,y2=[round(v/s) for v in (a,b,c,d)]
        iw,ih=self.cal_image.size
        self.cfg.update({"left":x1/iw,"top":y1/ih,"right":x2/iw,"bottom":y2/ih,"cols":12,"rows":12,"calibrated":True})
        with open(CONFIG,"w",encoding="utf-8") as f:json.dump(self.cfg,f,indent=2)
        try:self.cal_window.destroy()
        except:pass
        self.cal_window=None;self.status.set("Calibration saved.")

    def cancel_calibration(self):
        try:self.cal_window.destroy()
        except:pass
        self.cal_window=None

    # --- Lightweight digit recognition ---
    def binarize(self, img):
        g=ImageOps.grayscale(img)
        g=ImageEnhance.Contrast(g).enhance(4.0)
        g=g.resize((g.width*4,g.height*4),Image.Resampling.LANCZOS)
        # White stack text on dark background. Keep only bright pixels.
        return g.point(lambda p:255 if p>175 else 0)

    def components(self, bw):
        pix=bw.load(); w,h=bw.size
        # remove isolated noise with simple neighborhood count
        clean=Image.new("1",(w,h),0); cp=clean.load()
        for y in range(1,h-1):
            for x in range(1,w-1):
                if pix[x,y]:
                    n=sum(1 for yy in range(y-1,y+2) for xx in range(x-1,x+2) if pix[xx,yy])
                    if n>=2: cp[x,y]=1
        # connected components
        seen=set(); boxes=[]
        for y in range(h):
            for x in range(w):
                if not cp[x,y] or (x,y) in seen: continue
                stack=[(x,y)];seen.add((x,y));pts=[]
                while stack:
                    a,b=stack.pop();pts.append((a,b))
                    for q in ((a-1,b),(a+1,b),(a,b-1),(a,b+1)):
                        if 0<=q[0]<w and 0<=q[1]<h and cp[q[0],q[1]] and q not in seen:
                            seen.add(q);stack.append(q)
                if len(pts)>=4:
                    xs=[p[0] for p in pts];ys=[p[1] for p in pts]
                    boxes.append((min(xs),min(ys),max(xs)+1,max(ys)+1,len(pts)))
        return boxes

    def recognize_qty(self,slot):
        w,h=slot.size
        # The first region is the primary test; the other two are fallback
        # positions for layouts where the stack text is rendered elsewhere.
        regions=[
            slot.crop((0,0,int(w*.55),int(h*.40))),
            slot.crop((int(w*.45),int(h*.55),w,h)),
            slot.crop((0,int(h*.40),int(w*.60),h))
        ]
        best=None
        for region in regions:
            bw=self.binarize(region)
            boxes=self.components(bw)
            # Character-sized components. PoE2 text is tiny; reject very wide/tall noise.
            candidates=[b for b in boxes if 8<=b[4]<=3000 and
                        8<=b[2]-b[0]<=70 and 15<=b[3]-b[1]<=100]
            if not candidates: continue
            # A real quantity should form a compact left-to-right group.
            candidates.sort(key=lambda b:b[0])
            group=[candidates[0]]
            for b in candidates[1:]:
                gap=b[0]-group[-1][2]
                if gap < max(20,(group[-1][3]-group[-1][1])*1.5):
                    group.append(b)
                else:
                    if len(group)>=1:
                        break
            # We don't invent a number from arbitrary blobs. Return None unless
            # the group looks like small text; fallback to 1.
            if group:
                best=len(group)
                # v2.1 deliberately does not claim exact OCR from arbitrary shapes.
                # It exposes the number of digit-like components in the debug image.
                return None
        return None


    # ---------- poe.ninja reference database ----------
    def api_get_json(self,url):
        last_error=None
        for attempt in range(1,4):
            try:
                req=urllib.request.Request(
                    url,
                    headers={
                        "User-Agent":"PoE2-Top20-Overlay/2.6",
                        "Accept":"application/json"
                    }
                )
                with urllib.request.urlopen(req,timeout=30) as r:
                    raw=r.read()
                    status=getattr(r,"status",200)
                text=raw.decode("utf-8")
                data=json.loads(text)
                return data,status,len(raw)
            except Exception as ex:
                last_error=ex
                if attempt < 3:
                    time.sleep(1.0 * attempt)
        raise RuntimeError(
            f"API nach 3 Versuchen fehlgeschlagen: {url} | {last_error!r}"
        )

    def download_file(self,url,path):
        # poe.ninja can return absolute URLs, protocol-relative URLs, or
        # relative CDN paths.
        original=url
        if url.startswith("//"):
            url="https:"+url
        elif url.startswith("/"):
            url="https://web.poecdn.com"+url
        elif not url.lower().startswith(("http://","https://")):
            url="https://poe.ninja/"+url.lstrip("/")

        last_error=None
        # CDN/TLS connections can occasionally time out. Retry a few times
        # with a fresh HTTPS connection instead of aborting the whole batch.
        for attempt in range(1,4):
            try:
                req=urllib.request.Request(
                    url,
                    headers={
                        "User-Agent":"PoE2-Top20-Overlay/2.6",
                        "Accept":"image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
                        "Referer":"https://poe.ninja/",
                        "Accept-Language":"de-DE,de;q=0.9,en;q=0.8"
                    }
                )
                with urllib.request.urlopen(req,timeout=30) as r:
                    data=r.read()
                    status=getattr(r,"status",200)
                    ctype=r.headers.get("Content-Type","")
                if not data:
                    raise RuntimeError(f"HTTP {status}, leerer Inhalt")
                with open(path,"wb") as f:
                    f.write(data)
                return {
                    "url_original":original,"url_used":url,
                    "status":status,"content_type":ctype,
                    "bytes":len(data),"attempts":attempt
                }
            except Exception as ex:
                last_error=ex
                if attempt < 3:
                    time.sleep(1.0 * attempt)

        raise RuntimeError(
            f"Download nach 3 Versuchen fehlgeschlagen: {url} | {last_error!r}"
        )

    def resolve_reference_icon(self, ref):
        """Resolve a reference icon from the current installation only."""
        names=[]
        for key in ("icon_file_name","icon_file"):
            value=str(ref.get(key,"") or "")
            if value:
                names.append(os.path.basename(value))

        # Direct current-folder lookup.
        for name in names:
            p=os.path.join(REF_DIR,name)
            if os.path.isfile(p) and os.path.getsize(p)>0:
                try:
                    with Image.open(p) as im:
                        im.load()
                    return p
                except Exception:
                    pass

        # Last-resort lookup: some old JSON files contain an absolute path but
        # the basename still exists under the current reference_icons folder.
        try:
            wanted=set(names)
            if os.path.isdir(REF_DIR):
                for fn in os.listdir(REF_DIR):
                    if fn in wanted:
                        p=os.path.join(REF_DIR,fn)
                        try:
                            with Image.open(p) as im:
                                im.load()
                            return p
                        except Exception:
                            pass
        except Exception:
            pass
        return ""

    def reference_ready(self):
        if not os.path.exists(REF_JSON):
            return False
        try:
            with open(REF_JSON,encoding="utf-8") as f:
                d=json.load(f)
            if d.get("league") != LEAGUE:
                return False
            if d.get("charm_ref_version") != CHARM_REF_VERSION:
                return False
            items=d.get("items",[])
            if not items:
                return False
            # v5.96 requires the 12 normal/magic Charm base references.
            # This also invalidates the shared pre-v5.96 cache automatically
            # on the first launch after upgrading.
            base_charms=[x for x in items if x.get("base_charm")]
            if len(base_charms) < len(BASE_CHARM_REFS):
                return False
            valid=0
            for item in items:
                p=self.resolve_reference_icon(item)
                if not p:
                    continue
                try:
                    with Image.open(p) as im:
                        im.load()
                    valid += 1
                except Exception:
                    pass
            return valid >= max(20,int(len(items)*0.80))
        except Exception:
            return False


    def cleanup_reference_icons(self, refs):
        """Delete obsolete generated reference PNGs from the local cache."""
        expected=set()
        for ref in refs:
            url=str(ref.get("icon_url","") or "")
            if url and not str(ref.get("local_icon_file","") or ""):
                expected.add(hashlib.sha1(url.encode()).hexdigest()+".png")
            local_name=os.path.basename(str(ref.get("local_icon_file","") or ""))
            if local_name:
                expected.add(local_name)

        kept=removed=failed=0
        try:
            names=os.listdir(REF_DIR)
        except Exception as ex:
            self.log.insert("end",f"Reference cleanup skipped: {ex!r}")
            return

        for name in names:
            if not name.lower().endswith(".png"):
                continue
            path=os.path.join(REF_DIR,name)
            if name in expected:
                kept+=1
                continue
            try:
                os.remove(path)
                removed+=1
            except Exception as ex:
                failed+=1
                if failed<=3:
                    self.log.insert(
                        "end",
                        f"Reference cleanup failed: {name} | {ex!r}"
                    )

        self.log.insert(
            "end",
            f"Reference cleanup: kept={kept} removed={removed} "
            f"failed={failed} expected={len(expected)}"
        )
        self.root.update()

    def infer_stack_size(self, item_type, name):
        """Return a conservative PoE2 stack limit when the economy API does not expose one.

        Prefer the live API metadata when available.  These fallbacks cover the
        stackable families we have explicitly verified from the current PoE2
        stash/reference screens: Runes and Abyssal Bones use 20; Delirium
        liquids use 10.  Non-stackable items return 1 only where that is safe.
        """
        t=str(item_type or "").strip().lower()
        n=str(name or "").strip().lower()
        if t == "runes":
            return 20
        if t == "abyss":
            # The Abyssal Bones family (Gnawed/Preserved Jawbone, Rib,
            # Collarbone, Cranium) is stackable in 20s.
            if any(x in n for x in ("jawbone", "rib", "collarbone", "cranium")):
                return 20
        if t == "delirium":
            return 10
        if t == "essences":
            return 10
        return None

    def get_stack_size(self, item):
        """Get maximum stack size from poe.ninja metadata, then safe fallbacks."""
        for k in ("stack_size", "stackSize", "maxStackSize", "max_stack_size"):
            v=item.get(k) if isinstance(item,dict) else None
            try:
                v=int(v)
                if v>0:
                    return v
            except Exception:
                pass
        return self.infer_stack_size(item.get("type"), item.get("name"))

    def build_reference_database(self, force=False):
        if self.reference_ready() and not force:
            return True

        self.status.set("Lade poe.ninja General-References …")
        self.root.update()

        all_items={}
        raw_debug=[]
        try:
            for typ in GENERAL_TYPES:
                url=(
                    "https://poe.ninja/poe2/api/economy/"
                    "exchange/current/overview?league="+
                    urllib.parse.quote(LEAGUE,safe="")+"&type="+
                    urllib.parse.quote(typ,safe="")
                )
                data,status,raw_len=self.api_get_json(url)

                # The API has used both top-level and core metadata in the
                # wild; accept both shapes without assuming one.
                core=data.get("core") or {}
                lines=data.get("lines") or []
                core_items=core.get("items") or []
                top_items=data.get("items") or []

                if isinstance(core_items,dict):
                    core_items=list(core_items.values())
                if isinstance(top_items,dict):
                    top_items=list(top_items.values())

                # IMPORTANT:
                # top-level `items` is the metadata list matching lines[].id.
                # `core.items` contains only the primary/secondary reference
                # currencies (typically just a few entries).
                metadata=top_items if top_items else core_items

                self.log.insert(
                    "end",
                    f"{typ}: HTTP={status} lines={len(lines)} metadata={len(metadata)} "
                    f"(core={len(core_items)})"
                )
                self.root.update()

                raw_debug.append({
                    "type":typ,
                    "status":status,
                    "bytes":raw_len,
                    "top_keys":list(data.keys()),
                    "core_keys":list(core.keys()) if isinstance(core,dict) else []
                })

                # Build lookup from whichever ID/name fields are supplied.
                meta_by_id={}
                for item in metadata:
                    iid=item.get("id")
                    if iid is not None:
                        meta_by_id[str(iid)]=item

                for line in lines:
                    iid=line.get("id")
                    if iid is None: continue
                    meta=meta_by_id.get(str(iid),{})
                    name=meta.get("name") or line.get("name")
                    icon=meta.get("icon") or meta.get("image") or line.get("icon")
                    if not name or not icon:
                        continue

                    all_items[f"{typ}:{iid}"]={
                        "id":iid,
                        "name":name,
                        "icon_url":icon,
                        "type":typ,
                        "primary_value":line.get("primaryValue"),
                        "max_volume_currency":line.get("maxVolumeCurrency"),
                        "max_volume_rate":line.get("maxVolumeRate"),
                        # Some poe.ninja payloads expose stackSize/maxStackSize
                        # directly; retain whichever form is present.
                        "stack_size":(
                            line.get("stackSize") or line.get("maxStackSize") or
                            meta.get("stackSize") or meta.get("maxStackSize")
                        )
                    }

            # v5.96: add the 12 normal/magic Charm base icons. These are
            # deliberately synthetic references: they have no market price
            # here, but their icon is the canonical discriminator for all
            # normal/magic versions of that base. UniqueCharms from poe.ninja
            # remain separate and keep their own prices.
            for idx,(name,asset) in enumerate(BASE_CHARM_REFS,1):
                all_items[f"Charms:base:{idx}"]={
                    "id":f"base:{idx}",
                    "name":name,
                    "icon_url":f"https://web.poecdn.com/image/Art/2DItems/Charms/Basetypes/{asset}.png",
                    "local_icon_file":os.path.join("special_refs","charms",name.lower().replace(" ","_")+".png"),
                    "type":"Charms",
                    "primary_value":None,
                    "max_volume_currency":None,
                    "max_volume_rate":None,
                    "stack_size":1,
                    "base_charm":True,
                    "price_exempt":True,
                    "pricing_note":"Non-unique charm: utility item, no market price used"
                }
            self.log.insert("end", f"Charm base refs v5.96: added={len(BASE_CHARM_REFS)}")
            self.root.update()

            items=list(all_items.values())
            stack_known=0
            stack_fallback=0
            for item in items:
                raw_stack=item.get("stack_size")
                try:
                    raw_stack=int(raw_stack) if raw_stack is not None else None
                except Exception:
                    raw_stack=None
                if raw_stack and raw_stack>0:
                    item["stack_size"]=raw_stack
                    stack_known+=1
                else:
                    fb=self.infer_stack_size(item.get("type"), item.get("name"))
                    item["stack_size"]=fb
                    if fb:
                        stack_fallback+=1
            self.log.insert(
                "end",
                f"GESAMT: {len(items)} Referenz-Items mit Icon-Metadaten | "
                f"stack_size API={stack_known} fallback={stack_fallback}"
            )
            self.root.update()

            if not items:
                self.status.set(
                    "API antwortet, aber keine Item/Icon-Kombination gefunden. "
                    "api_debug.json wurde gespeichert."
                )
                return False

            with open(REF_JSON,"w",encoding="utf-8") as f:
                json.dump({
                    "league":LEAGUE,
                    "created":time.time(),
                    "charm_ref_version":CHARM_REF_VERSION,
                    "items":items
                },f,indent=2,ensure_ascii=False)

            # Remove stale generated icons before downloading the current set.
            # Only the local reference cache is touched.
            self.cleanup_reference_icons(items)

            total=len(items)
            ok_icons=0
            failed_icons=0
            skipped_icons=0
            download_debug=[]

            # Windows ZIP extraction may omit empty directories. Create it
            # explicitly before any icon is written.
            os.makedirs(REF_DIR, exist_ok=True)

            # Download several icons in parallel so a slow CDN request cannot
            # make the whole Tkinter window look frozen.
            from concurrent.futures import ThreadPoolExecutor, as_completed

            def download_one(item):
                local_src=str(item.get("local_icon_file","") or "")
                if local_src:
                    fn=os.path.basename(local_src)
                else:
                    fn=hashlib.sha1(item["icon_url"].encode()).hexdigest()+".png"
                path=os.path.join(REF_DIR,fn)
                item["icon_file"]=path
                item["icon_file_name"]=fn

                # Build-in local references are copied from the application bundle.
                if local_src:
                    src=os.path.join(APP,local_src)
                    try:
                        if os.path.isfile(src) and os.path.getsize(src)>0:
                            with Image.open(src) as im:
                                im.convert("RGBA").save(path,"PNG")
                            return ("local", item, {"path":path})
                        raise FileNotFoundError(src)
                    except Exception as ex:
                        item["icon_file"]=""
                        return ("error", item, {"error":repr(ex)})

                # Existing file is only reusable if PIL can actually decode it.
                if os.path.exists(path) and os.path.getsize(path)>0:
                    try:
                        with Image.open(path) as im:
                            im.load()
                        return ("skip", item, {"path":path})
                    except Exception:
                        try: os.remove(path)
                        except Exception: pass

                tmp=path+".download"
                try:
                    info=self.download_file(item["icon_url"],tmp)
                    with Image.open(tmp) as im:
                        im.convert("RGBA").save(path,"PNG")
                    try: os.remove(tmp)
                    except Exception: pass
                    info["decoded"]=True
                    return ("ok", item, info)
                except Exception as ex:
                    try:
                        if os.path.exists(tmp): os.remove(tmp)
                        if os.path.exists(path): os.remove(path)
                    except Exception:
                        pass
                    item["icon_file"]=""
                    return ("error", item, {"error":repr(ex)})

            self.log.insert("end",
                f"=== ICON DOWNLOAD: {total} Bilder, 8 parallele Downloads ===")
            self.log.insert("end", f"Target folder: {REF_DIR}")
            self.root.update()

            with ThreadPoolExecutor(max_workers=8) as pool:
                futures=[pool.submit(download_one,item) for item in items]
                done=0
                for fut in as_completed(futures):
                    kind,item,info=fut.result()
                    done += 1
                    if kind in ("ok","local"):
                        ok_icons += 1
                        if len(download_debug)<8:
                            download_debug.append({
                                "name":item["name"],
                                "icon_url":item["icon_url"],
                                "result":info
                            })
                    elif kind=="skip":
                        skipped_icons += 1
                    else:
                        failed_icons += 1
                        if len(download_debug)<8:
                            download_debug.append({
                                "name":item["name"],
                                "icon_url":item["icon_url"],
                                "error":info["error"]
                            })

                    if done%10==0 or done==total:
                        self.status.set(
                            f"Reference icons: {done}/{total} "
                            f"(OK {ok_icons}, vorhanden {skipped_icons}, Fehler {failed_icons})"
                        )
                        self.root.update()

            usable_now=0
            for it in items:
                pth=it.get("icon_file","")
                if pth and os.path.exists(pth):
                    try:
                        with Image.open(pth) as im:
                            im.load()
                        usable_now += 1
                    except Exception:
                        pass

            self.log.insert(
                "end",
                f"ICONS: neu loaded={ok_icons} already present={skipped_icons} "
                f"failed={failed_icons} | usable={usable_now}/{total}"
            )
            charm_usable=sum(1 for it in items if it.get("base_charm") and it.get("icon_file") and os.path.isfile(it.get("icon_file","")))
            self.log.insert("end", f"CHARM REFS {CHARM_REF_VERSION}: usable={charm_usable}/{len(BASE_CHARM_REFS)}")
            self.root.update()

            self.safe_json_dump(ICON_DEBUG,download_debug,quiet=True)

            # Store portable icon filenames rather than machine-specific
            # absolute paths. The matcher resolves them relative to
            # reference_icons at runtime.
            portable_items=[]
            for item in items:
                q=dict(item)
                q["icon_file_name"]=os.path.basename(q.get("icon_file",""))
                q["icon_file"]=q["icon_file_name"]
                portable_items.append(q)

            # Keep the exact normalized records in memory too. The matcher
            # must not depend on a stale copy of the pre-normalized JSON.
            items[:] = portable_items

            with open(REF_JSON,"w",encoding="utf-8") as f:
                json.dump({
                    "league":LEAGUE,
                    "created":time.time(),
                    "charm_ref_version":CHARM_REF_VERSION,
                    "items":portable_items
                },f,indent=2,ensure_ascii=False)

            usable=sum(1 for item in portable_items if self.resolve_reference_icon(item))
            self.log.insert(
                "end",
                f"ICONS: loaded={ok_icons} failed={failed_icons} | "
                f"usable={usable}/{len(portable_items)}"
            )
            self.log.insert("end", "icon_download_debug.json gespeichert")
            self.root.update()

            if usable_now == 0:
                self.status.set(
                    "Reference items found, but no reference icons could be decoded. "
                    "See icon_download_debug.json."
                )
                return False
            return True

        except Exception as e:
            self.status.set("poe.ninja/API Error: "+repr(e))
            self.log.insert("end",f"FEHLER: {repr(e)}")
            self.root.update()
            return False

    def normalize_icon(self,img):
        # Remove only the small top-left stack-number zone consistently from
        # both query and reference icons. Do NOT normalize away color/brightness:
        # rune tiers and differently colored item variants need those cues.
        im=img.convert("RGB")
        w,h=im.size
        p=max(1,round(min(w,h)*0.02))
        im=im.crop((p,p,w-p,h-p))
        im=im.resize((96,96),Image.Resampling.LANCZOS)

        # The stack number occupies the upper-left corner. Mask the same area
        # in reference and query images so the number itself cannot influence
        # the item match.
        d=ImageDraw.Draw(im)
        zw=round(im.width*0.22)
        zh=round(im.height*0.20)
        # Use a local dark/background color instead of a bright artificial block.
        bg=im.getpixel((zw+2,zh+2))
        d.rectangle((0,0,zw,zh),fill=bg)
        return im


    def icon_signature(self,img):
        """PIL-only icon signature with a dedicated interior color descriptor."""
        im=self.normalize_icon(img).convert("RGB").resize(
            (40,40),Image.Resampling.BILINEAR)
        vals=[]

        # Ignore the outer border and the top-left stack-count area for the
        # color signature. This is especially important for Delirium liquids.
        inner=im.crop((5,5,35,35))

        # 5x5 spatial RGB blocks: preserves where the main color is located.
        pix=list(inner.getdata())
        for by in range(5):
            for bx in range(5):
                rs=[]; gs=[]; bs=[]
                for y in range(by*6,(by+1)*6):
                    for x in range(bx*6,(bx+1)*6):
                        r,g,b=pix[y*30+x]
                        rs.append(r); gs.append(g); bs.append(b)
                vals.extend((
                    sum(rs)/len(rs)/255.0,
                    sum(gs)/len(gs)/255.0,
                    sum(bs)/len(bs)/255.0
                ))

        # HSV spatial blocks. Hue is circular; encode hue as sin/cos so
        # neighboring hues remain meaningfully close.
        hsv=inner.convert("HSV")
        hp=[]; sp=[]; vp=[]
        for h,ss,v in hsv.getdata():
            hp.append(h); sp.append(ss); vp.append(v)
        for by in range(5):
            for bx in range(5):
                hs=[]; ss=[]; vs=[]
                for y in range(by*6,(by+1)*6):
                    for x in range(bx*6,(bx+1)*6):
                        i=y*30+x
                        hs.append(hp[i]); ss.append(sp[i]); vs.append(vp[i])
                import math
                ang=[2*math.pi*h/256.0 for h in hs]
                vals.extend((
                    sum(math.cos(q) for q in ang)/len(ang),
                    sum(math.sin(q) for q in ang)/len(ang),
                    sum(ss)/len(ss)/255.0,
                    sum(vs)/len(vs)/255.0
                ))

        # Global HSV histograms for overall color identity.
        bins_h=24; bins_s=8; bins_v=8
        hh=[0.0]*bins_h; sh=[0.0]*bins_s; vh=[0.0]*bins_v
        for h,ss,v in zip(hp,sp,vp):
            hh[min(bins_h-1,int(h/(256/bins_h)))] += 1
            sh[min(bins_s-1,int(ss/(256/bins_s)))] += 1
            vh[min(bins_v-1,int(v/(256/bins_v)))] += 1
        total=float(len(hp))
        vals.extend(x/total for x in hh)
        vals.extend(x/total for x in sh)
        vals.extend(x/total for x in vh)

        # Secondary grayscale structure, downweighted by signature_distance.
        gray=inner.convert("L").resize((20,20),Image.Resampling.BILINEAR)
        vals.extend(v/255.0 for v in gray.getdata())
        return vals


    def special_icon_vector(self, img):
        """Small robust color/shape descriptor for local special references.

        Used only for items whose current poe.ninja reference set can miss a
        newly introduced/variant icon. The descriptor ignores the same UI
        overlay zones that are visible in the 67x67 calibration grid.
        """
        im=self.normalize_icon(img).convert("RGB")
        a=np.asarray(im,dtype=np.float32)
        mask=np.ones((96,96),dtype=bool)
        # Stack number / grid coordinate / debug ICON label.
        mask[:20,:24]=False
        mask[:20,72:]=False
        mask[54:,58:]=False
        mask[:4,:]=False; mask[-4:,:]=False
        mask[:,:4]=False; mask[:,-4:]=False
        vals=[]
        for by in range(8):
            for bx in range(8):
                yy=slice(by*12,(by+1)*12); xx=slice(bx*12,(bx+1)*12)
                mm=mask[yy,xx]
                pix=a[yy,xx][mm]
                if len(pix):
                    vals.extend((pix.mean(axis=0)/255.0).tolist())
                else:
                    vals.extend((0.0,0.0,0.0))
        return np.asarray(vals,dtype=np.float32)

    def load_charm_special_refs(self):
        """Load the 12 canonical Charm base icons shipped with the build."""
        if hasattr(self,"_charm_special_refs"):
            return self._charm_special_refs
        out=[]
        try:
            files=sorted(os.listdir(LOCAL_CHARM_REF_DIR))
        except Exception:
            files=[]
        for fn in files:
            if not fn.lower().endswith((".png",".jpg",".jpeg",".webp")):
                continue
            name=os.path.splitext(fn)[0].replace("_"," ").strip().title()
            if not name.endswith(" Charm"):
                continue
            try:
                with Image.open(os.path.join(LOCAL_CHARM_REF_DIR,fn)) as im:
                    vec=self.special_icon_vector(im.copy())
                out.append((name,vec))
            except Exception:
                pass
        self._charm_special_refs=out
        return out

    def load_special_icon_refs(self):
        if hasattr(self,"_special_icon_refs"):
            return self._special_icon_refs
        out=[]
        p=os.path.join(APP,"special_refs")
        try:
            files=sorted(os.listdir(p))
        except Exception:
            files=[]
        for fn in files:
            if not fn.lower().endswith((".png",".jpg",".jpeg",".webp")):
                continue
            name=os.path.splitext(fn)[0].replace("_"," ").strip().lower()
            # Only local references explicitly shipped with this build.
            if name=="ancient concentrated liquid isolation":
                item_name="Ancient Concentrated Liquid Isolation"
            else:
                continue
            try:
                with Image.open(os.path.join(p,fn)) as im:
                    vec=self.special_icon_vector(im.copy())
                out.append((item_name,vec))
            except Exception:
                pass
        self._special_icon_refs=out
        return out

    def load_stash_seed_refs(self):
        """Load supervised per-slot references captured from the calibration stash.

        v6.29: the previous build shipped 20 known-good stash samples but never
        loaded them.  The manifest binds each sample to its original row/column,
        so these seeds are used only when the same stash slot is scanned again.
        This prevents a visually similar item from being mislabeled just because
        it resembles a seed belonging to another slot.
        """
        if hasattr(self,"_stash_seed_refs"):
            return self._stash_seed_refs
        out=[]
        try:
            with open(LOCAL_STASH_SEED_MANIFEST,encoding="utf-8") as f:
                manifest=json.load(f)
        except Exception:
            manifest=[]
        for rec in manifest if isinstance(manifest,list) else []:
            try:
                fn=str(rec.get("file",""))
                name=str(rec.get("name",""))
                row=int(rec.get("row")); col=int(rec.get("col"))
                if not fn or not name or row<1 or col<1:
                    continue
                path=os.path.join(LOCAL_STASH_SEED_DIR,fn)
                with Image.open(path) as im:
                    vec=self.special_icon_vector(im.copy())
                out.append({"row":row,"col":col,"name":name,"vec":vec,"file":path})
            except Exception:
                continue
        self._stash_seed_refs=out
        return out

    def special_icon_distance(self,a,b):
        av=self.special_icon_vector(a) if isinstance(a,Image.Image) else np.asarray(a)
        bv=self.special_icon_vector(b) if isinstance(b,Image.Image) else np.asarray(b)
        return float(np.sqrt(np.mean((av-bv)**2)))

    def signature_distance(self,a,b):
        """
        Distance for v5.65. The first 225 values are spatial RGB, the next
        100 are spatial HSV, then 40 HSV histograms, then 400 grayscale values.
        """
        n=min(len(a),len(b))
        # v5.22 signature length: 75 RGB + 100 HSV + 40 histograms
        # + 400 grayscale = 615 values.
        if n < 615:
            return 1.0
        groups=(
            (0,75,0.34),      # spatial RGB
            (75,175,0.42),    # spatial HSV/color
            (175,215,0.18),   # global HSV histograms
            (215,615,0.06),   # grayscale structure
        )
        total=0.0
        for lo,hi,w in groups:
            hi=min(hi,n)
            if hi<=lo: continue
            d=sum((a[i]-b[i])**2 for i in range(lo,hi))/(hi-lo)
            total += w*(d**0.5)
        return total


    def rune_idol_signature_distance(self,a,b):
        """Shape-aware distance used only for Rune/Idol references.

        Rune and Idol icons share a lot of blue/purple color information, so
        the generic economy matcher can over-weight color and under-weight the
        actual glyph/silhouette.  Keep the existing matcher untouched for all
        other item families and use a second metric for Rune/Idol references.
        """
        n=min(len(a),len(b))
        if n < 615:
            return 1.0
        groups=(
            (0,75,0.30),      # spatial RGB
            (75,175,0.30),    # spatial HSV/color
            (175,215,0.12),   # global HSV histograms
            (215,615,0.28),   # grayscale shape
        )
        total=0.0
        for lo,hi,w in groups:
            hi=min(hi,n)
            if hi<=lo:
                continue
            d=sum((a[i]-b[i])**2 for i in range(lo,hi))/(hi-lo)
            total += w*(d**0.5)
        return total

    def reference_reverse_rank(self, ref, query_sigs):
        """Rank a reference against all occupied stash icons (v6.15).

        Lower is better.  Rank 0 means the reference is the closest reference
        for at least one stash icon when compared with the full reference set.
        This is used as a mutual-nearest support signal, not as a standalone
        identity decision.
        """
        rs=ref.get("_sig")
        if rs is None or not query_sigs:
            return 999
        rtype=str(ref.get("type", ""))
        fam=matcher_family(rtype)
        best_ranks=[]
        for qs,all_best in query_sigs:
            # all_best is already sorted (distance, reference).
            rank=999
            for idx,(d,rr) in enumerate(all_best):
                if rr is ref or rr.get("name")==ref.get("name") and rr.get("type")==rtype:
                    rank=idx
                    break
            best_ranks.append(rank)
        return min(best_ranks) if best_ranks else 999

    def local_icon_distance(self, a, b):
        """Compare the actual item art, independent of stash position/UI.

        v6.29 fixes an important weakness in the v6.03 second-stage matcher:
        the query was a 190/192px stash crop while the poe.ninja reference is
        normally a bare item icon. Comparing those raw images made the pixel
        rescue almost useless because the query still contained the green
        slot frame and the bottom ``ICON`` debug label.

        Both sides are now normalized first and the comparison is restricted
        to the central art area. Quantity, coordinates, borders and the debug
        label cannot influence the result.
        """
        def prep(img):
            im=self.normalize_icon(img).convert("RGB").resize(
                (96,96),Image.Resampling.LANCZOS)
            a=np.asarray(im,dtype=np.float32)/255.0
            # normalize_icon already removes the quantity corner. These masks
            # additionally remove stash/debug-only regions which do not exist
            # in a poe.ninja reference icon.
            a[:4,:]=0.0; a[-4:,:]=0.0
            a[:,:4]=0.0; a[:,-4:]=0.0
            a[:16,72:]=0.0       # stash coordinate/debug text
            a[78:,:]=0.0         # bottom ``ICON`` label in debug captures
            return a
        aa=prep(a); bb=prep(b)
        core=aa[8:78,8:88]-bb[8:78,8:88]
        return float(np.mean(core*core))

    def load_visual_atlas(self):
        """Load conservative exact-icon seeds learned from previous scans.

        Atlas entries are not a replacement for the economy matcher. They are
        only used as a second, exact-visual identity check for icons that have
        already been matched with strong independent evidence.
        """
        if hasattr(self, "_visual_atlas"):
            return self._visual_atlas
        out=[]
        try:
            with open(VISUAL_ATLAS_JSON,encoding="utf-8") as f:
                meta=json.load(f)
            if str(meta.get("version", "")) != VISUAL_ATLAS_VERSION:
                self.log.insert("end", f"VISUAL ATLAS {VISUAL_ATLAS_VERSION}: old atlas ignored")
                meta={"entries":[]}
            for rec in meta.get("entries",[]):
                path=rec.get("path","")
                if path and not os.path.isfile(path) and not os.path.isabs(path):
                    path=os.path.join(DATA_DIR,path)
                if not path or not os.path.isfile(path):
                    continue
                try:
                    with Image.open(path) as im:
                        sig=im.copy()
                    out.append((rec,sig))
                except Exception:
                    continue
        except Exception:
            pass
        self._visual_atlas=out
        self.log.insert("end",f"VISUAL ATLAS v6.29: {len(out)} exact seeds loaded")
        return out

    def learn_visual_atlas(self, results, icons):
        """Persist only very strong, independently verified icon identities."""
        try:
            atlas=self.load_visual_atlas()
            entries=[]
            try:
                with open(VISUAL_ATLAS_JSON,encoding="utf-8") as f:
                    entries=json.load(f).get("entries",[])
            except Exception:
                entries=[]
            by_key={(e.get("name"),e.get("type"),e.get("source")):e for e in entries}
            icon_by_rc={(x["row"],x["col"]):x for x in icons}
            learned=0
            for rr in results:
                if not rr.get("accepted") or not rr.get("matches"):
                    continue
                conf=rr.get("confidence",{})
                m=rr["matches"][0]
                name=str(m.get("name","")).strip()
                typ=str(m.get("type","")).strip()
                d=float(conf.get("distance",1.0))
                pixel_exact=bool(conf.get("pixel_exact",False))
                # Conservative learning gates. A seed must either have an
                # independently decisive pixel verification or be an unusually
                # close generic match. Broad Charm/Rune rescue matches are not
                # allowed to poison the persistent atlas.
                strong=(pixel_exact and d <= 0.090)
                if not strong or not name:
                    continue
                icon=icon_by_rc.get((rr["row"],rr["col"]))
                if not icon:
                    continue
                src=icon.get("icon_clean")
                if not src or not os.path.isfile(src):
                    continue
                key=(name,typ,"slot")
                if key in by_key:
                    continue
                safe=os.path.join(VISUAL_ATLAS_DIR, hashlib.sha1(f"{name}|{typ}|{rr['row']}|{rr['col']}".encode()).hexdigest()[:16]+".png")
                try:
                    with Image.open(src) as im:
                        im.save(safe)
                except Exception:
                    continue
                rec={"name":name,"type":typ,"path":safe,"source":"slot","distance":d}
                entries.append(rec); by_key[key]=rec; learned+=1
            if learned:
                self.safe_json_dump(VISUAL_ATLAS_JSON,{"version":VISUAL_ATLAS_VERSION,"entries":entries},quiet=True)
                self._visual_atlas=None
                self.load_visual_atlas()
            self.log.insert("end",f"VISUAL ATLAS v6.29: learned={learned} total={len(entries)}")
        except Exception as ex:
            self.log.insert("end",f"VISUAL ATLAS v6.29 ERROR: {ex!r}")

    def identify_icons(self, folder, icons):
        if not icons:
            return []

        try:
            with open(REF_JSON,encoding="utf-8") as f:
                refs=json.load(f).get("items",[])
        except Exception as ex:
            self.log.insert("end",f"Reference JSON error: {ex!r}")
            return []

        # v6.29: user-confirmed negative references. The current stash has been
        # checked independently and these two names are definitely absent.
        # Remove them from ALL economy matching, so a visually similar icon
        # cannot promote a 30+ Divine false positive into the Top 20.
        if CONFIRMED_ABSENT_NAMES:
            refs=[r for r in refs if str(r.get("name","" )).strip() not in CONFIRMED_ABSENT_NAMES]
            self.log.insert(
                "end",
                "CONFIRMED ABSENT v6.29: " + ", ".join(sorted(CONFIRMED_ABSENT_NAMES))
            )

        # v6.29: derive Rune tier families from the actual poe.ninja item set.
        # This prevents names containing "Greater" from being treated as a
        # tier when they are actually one-stage special cases.
        tier_map=build_rune_tier_map(refs)
        self.log.insert(
            "end",
            f"RUNE TIERS v6.29: {len(tier_map)} confirmed tiered entries / "
            f"{len({r.get('name') for r in refs if r.get('type')=='Runes'})} total Runes"
        )

        # The downloader names every icon:
        # sha1(icon_url).png
        # Recreate that filename directly from the API metadata. This avoids
        # all absolute/relative path and icon_file/icon_file_name mismatches.
        ref_by_filename={}
        for ref in refs:
            url=str(ref.get("icon_url","") or "")
            if not url:
                continue
            fn=hashlib.sha1(url.encode()).hexdigest()+".png"
            ref_by_filename[fn]=ref

        try:
            physical=[fn for fn in os.listdir(REF_DIR)
                       if fn.lower().endswith((".png",".jpg",".jpeg",".webp",".gif",".bmp"))]
        except Exception:
            physical=[]

        usable_files=[]
        decode_failed=0
        unmapped=0
        for fn in physical:
            ref=ref_by_filename.get(fn)
            if ref is None:
                unmapped += 1
                continue
            p=os.path.join(REF_DIR,fn)
            try:
                with Image.open(p) as rim:
                    rim.load()
                    sig=self.icon_signature(rim.copy())
                usable_files.append((ref,sig))
            except Exception as ex:
                decode_failed += 1
                if decode_failed <= 3:
                    self.log.insert(
                        "end",
                        f"Reference decode failed: {fn} | {type(ex).__name__}: {ex}"
                    )

        self.log.insert(
            "end",
            f"Matcher input: {len(icons)} occupied icons, "
            f"{len(usable_files)} usable reference icons, "
            f"{len(refs)-len(usable_files)} unusable."
        )
        self.log.insert(
            "end",
            f"Reference folder: {len(physical)} PNG files | "
            f"mapped={len(usable_files)} | unmapped={unmapped} | "
            f"decode_failed={decode_failed}"
        )
        self.root.update()

        special_refs=self.load_special_icon_refs()
        stash_seed_refs=self.load_stash_seed_refs()
        charm_special_refs=self.load_charm_special_refs()
        if special_refs:
            self.log.insert("end", f"Special icon references: {len(special_refs)} loaded")
        self.log.insert("end", f"STASH SEEDS v6.29: {len(stash_seed_refs)} supervised slot refs loaded")
        self.log.insert("end", f"CHARM SPECIAL v6.29: {len(charm_special_refs)}/12 bases loaded")

        # v6.29: precompute signature rankings for the complete stash once.
        # This lets us perform a mutual-nearest check later without repeating
        # the expensive reference loop for every accepted result.
        query_sig_rows=[]
        for _it in icons:
            try:
                with Image.open(_it["icon_clean"]) as _qim:
                    _qs=self.icon_signature(_qim.copy())
                _all=[]
                for _ref,_rs in usable_files:
                    _rtype=str(_ref.get("type", "") or "")
                    _d=(self.rune_idol_signature_distance(_qs,_rs)
                        if _rtype in ("Runes","Idols") else
                        self.signature_distance(_qs,_rs))
                    _all.append((_d,_ref))
                _all.sort(key=lambda x:x[0])
                query_sig_rows.append((_it,_qs,_all))
            except Exception:
                continue
        # Attach the signature to each reference object so the reverse-rank
        # helper can work without rebuilding the reference image descriptors.
        for _ref,_rs in usable_files:
            _ref["_sig"]=_rs
        reverse_support_cache={}
        for _it,_qs,_all in query_sig_rows:
            for _rank,_dref in enumerate(_all[:8]):
                _key=(str(_dref[1].get("name","")),str(_dref[1].get("type","")))
                old=reverse_support_cache.get(_key,999)
                if _rank < old:
                    reverse_support_cache[_key]=_rank
        self.log.insert("end",f"MUTUAL SUPPORT v6.29: {len(query_sig_rows)} stash icons ranked | {len(reverse_support_cache)} refs supported")

        results=[]
        if not usable_files and not special_refs:
            self.log.insert("end","Matcher stopped: no usable mapped reference images.")
            return results

        for item in icons:
            try:
                with Image.open(item["icon_clean"]) as qimg:
                    qs=self.icon_signature(qimg.copy())
            except Exception:
                continue

            # v5.83: local special reference rescue for the one new Ancient
            # liquid whose icon can be absent from the economy reference cache.
            # It is deliberately independent of the generic matcher and only
            # accepts the exact named local reference below a tight distance.
            special_best=None
            if special_refs:
                try:
                    with Image.open(item["icon_clean"]) as qicon:
                        qcopy=qicon.copy()
                    for special_name,svec in special_refs:
                        sd=self.special_icon_distance(qcopy,svec)
                        if special_best is None or sd<special_best[0]:
                            special_best=(sd,special_name)
                except Exception:
                    special_best=None

            stash_seed_best=None
            if stash_seed_refs:
                try:
                    with Image.open(item["icon_clean"]) as qicon:
                        qcopy=qicon.copy()
                    for seed in stash_seed_refs:
                        if seed["row"]!=item["row"] or seed["col"]!=item["col"]:
                            continue
                        sd=self.special_icon_distance(qcopy,seed["vec"])
                        stash_seed_best=(sd,seed["name"])
                        break
                except Exception:
                    stash_seed_best=None

            charm_best=None
            if charm_special_refs:
                try:
                    with Image.open(item["icon_clean"]) as qicon:
                        qcopy=qicon.copy()
                    for charm_name,cvec in charm_special_refs:
                        cd=self.special_icon_distance(qcopy,cvec)
                        if charm_best is None or cd<charm_best[0]:
                            charm_best=(cd,charm_name)
                except Exception:
                    charm_best=None

            # v6.29: exact visual atlas. These are real slot crops learned
            # only from strong matches in earlier scans. They are checked
            # before the generic economy references and can only become
            # decisive when the visual match is essentially exact.
            atlas_best=None
            atlas_exact=False
            atlas=self.load_visual_atlas()
            if atlas and CONFIRMED_ABSENT_NAMES:
                atlas=[(arec,asim) for arec,asim in atlas
                       if str(arec.get("name","" )).strip() not in CONFIRMED_ABSENT_NAMES]
            if atlas:
                try:
                    with Image.open(item["icon_clean"]) as _qim:
                        _qcopy=_qim.copy()
                    for arec,asim in atlas:
                        ad=self.local_icon_distance(_qcopy,asim)
                        if atlas_best is None or ad < atlas_best[0]:
                            atlas_best=(ad,arec)
                    # Atlas entries are learned from independently verified
                    # slot icons. Only an essentially pixel-identical crop is
                    # allowed to become decisive; otherwise the normal matcher
                    # remains authoritative.
                    if atlas_best is not None and atlas_best[0] <= 0.0012:
                        atlas_exact=True
                except Exception:
                    atlas_best=None
                    atlas_exact=False

            if atlas_best is not None:
                self.log.insert(
                    "end",
                    f"VISUAL ATLAS v6.29 r{item['row']:02d}c{item['col']:02d}: "
                    f"best={atlas_best[1].get('name','?')} d={atlas_best[0]:.6f} "
                    f"decisive={atlas_exact}"
                )

            best=[]
            for ref,rs in usable_files:
                ref_type=str(ref.get("type","") or "")
                if ref_type in ("Runes","Idols"):
                    d=self.rune_idol_signature_distance(qs,rs)
                else:
                    d=self.signature_distance(qs,rs)
                best.append((d,ref))
            best.sort(key=lambda x:x[0])
            top=best[:5]

            # v6.29 DIAGNOSTIC: keep the algorithm unchanged, but expose a
            # wider ranked candidate window so the next test tells us whether
            # the correct icon is present but merely ranked too low. This is
            # read-only and intentionally does not affect the decision.
            if best:
                _diag_parts=[]
                for _idx,(_dd,_rr) in enumerate(best[:10],1):
                    _diag_parts.append(
                        f"#{_idx}={_rr.get('name','?')}[{_rr.get('type','?')}]/{_dd:.5f}"
                    )
                self.log.insert(
                    "end",
                    f"DIAG CANDIDATES v6.29 r{item['row']:02d}c{item['col']:02d}: "
                    + " | ".join(_diag_parts)
                )

            # v6.29: reverse/mutual support.  A candidate that is merely the
            # least-bad reference for this slot but is not near the top for any
            # stash icon is a classic false positive.  Keep the signal separate
            # so existing visual checks remain intact.
            reverse_rank=999
            if top:
                _tk=(str(top[0][1].get("name","")),str(top[0][1].get("type","")))
                reverse_rank=reverse_support_cache.get(_tk,999)
            self.log.insert("end",f"MUTUAL v6.29 r{item['row']:02d}c{item['col']:02d}: {top[0][1].get('name','?') if top else '?'} reverse_rank={reverse_rank}")

            # v6.29: exact visual second-stage matching. The economy signature
            # is intentionally tolerant and can put a visually similar item
            # ahead of the real icon. Compare the captured icon directly with
            # the best generic reference candidates as a second, high-precision
            # check. The UI-only areas are masked by local_icon_distance().
            # This is deliberately a rescue only: a very close pixel match is
            # stronger evidence than the abstract signature, while the generic
            # matcher remains the fallback for items whose reference rendering
            # differs slightly.
            pixel_exact=False
            pixel_best=None
            pixel_agrees=False
            try:
                with Image.open(item["icon_clean"]) as _qim:
                    _qcopy=_qim.copy()
                pixel_candidates=[]
                # v6.29: pixel comparison is a verifier, not an automatic
                # winner. Visual similarity must agree with the independent
                # signature matcher unless the pixel match is exceptionally
                # close. This reduces false high-value look-alikes.
                # v6.29: the generic signature can rank a visually similar
                # Rune/Idol outside the old top-40.  Use a wider verifier pool
                # so the exact visual check can actually find the real icon.
                # Keep the wider pass limited to Rune/Idol families to avoid
                # unnecessary work across the whole economy reference set.
                # v6.29: the previous 80/180 cap could miss the real icon when
                # the color signature ranked it far behind a visually similar
                # reference. Use a wider verifier for every family. The exact
                # pixel stage is still conservative; it only becomes decisive
                # at the very small local-distance thresholds below.
                verifier_limit = len(best)
                for _cd,_cr in best[:verifier_limit]:
                    _rp=self.resolve_reference_icon(_cr)
                    if not _rp:
                        continue
                    try:
                        with Image.open(_rp) as _rim:
                            _pd=self.local_icon_distance(_qcopy,_rim.copy())
                        pixel_candidates.append((_pd,_cr))
                    except Exception:
                        continue
                pixel_candidates.sort(key=lambda x:x[0])
                if pixel_candidates:
                    # v6.29 DIAGNOSTIC: show the direct-image ranking as well.
                    # This lets us distinguish a bad generic signature from a
                    # genuinely wrong visual reference. No thresholds change.
                    _pdiag=[]
                    for _idx,(_pd0,_cr0) in enumerate(pixel_candidates[:8],1):
                        _pdiag.append(
                            f"#{_idx}={_cr0.get('name','?')}[{_cr0.get('type','?')}]/{_pd0:.6f}"
                        )
                    self.log.insert(
                        "end",
                        f"DIAG PIXEL v6.29 r{item['row']:02d}c{item['col']:02d}: "
                        + " | ".join(_pdiag)
                    )
                    pixel_best=pixel_candidates[0]
                    pixel_second=pixel_candidates[1] if len(pixel_candidates)>1 else (9.0,None)
                    pixel_gap=float(pixel_second[0]-pixel_best[0])
                    generic_name=top[0][1].get('name','').strip().lower() if top else ''
                    pixel_name=pixel_best[1].get('name','').strip().lower()
                    pixel_agrees=bool(generic_name and generic_name==pixel_name)
                    # v6.29: use the full reference pool and a margin-aware
                    # pixel decision. A real icon should not only be close to
                    # its reference; it should also be clearly closer than the
                    # next reference. This is much safer than simply raising
                    # the absolute pixel threshold.
                    pixel_exact=(pixel_best[0] <= 0.0030 and pixel_agrees) or (
                        pixel_best[0] <= 0.0065 and pixel_gap >= 0.0009
                    ) or (pixel_best[0] <= 0.0012)
                    self.log.insert(
                        "end",
                        f"PIXEL VERIFY v6.29 r{item['row']:02d}c{item['col']:02d}: "
                        f"best={pixel_best[1].get('name','?')} d={pixel_best[0]:.6f} "
                        f"second={pixel_second[1].get('name','?') if pixel_second[1] else '?'} "
                        f"gap={pixel_gap:.6f} generic={top[0][1].get('name','?') if top else '?'} "
                        f"agree={pixel_agrees} decisive={pixel_exact}"
                    )
                    # v6.29: Rune-specific visual rescue. The generic signature
                    # is systematically too color-heavy for runes and can rank
                    # a different Rune (or even a Verisium item) ahead of the
                    # actual icon. The direct icon comparison is much more useful
                    # here. If a Rune reference is clearly the closest visual
                    # match, let it replace the generic winner even when the
                    # generic candidate is otherwise accepted.
                    pixel_best_type = str(pixel_best[1].get("type", "")) if pixel_best else ""
                    generic_type = str(top[0][1].get("type", "")) if top else ""
                    rune_pixel_rescue = bool(
                        pixel_best is not None and
                        pixel_best_type == "Runes" and
                        generic_type != "Runes" and
                        pixel_best[0] <= 0.0650 and
                        pixel_gap >= 0.0010
                    )
                    if rune_pixel_rescue:
                        top=[pixel_best]+[x for x in top if x[1] is not pixel_best[1]]
                        self.log.insert(
                            "end",
                            f"RUNE PIXEL OVERRIDE v6.29 r{item['row']:02d}c{item['col']:02d}: "
                            f"{pixel_best[1].get('name','?')} d={pixel_best[0]:.6f} gap={pixel_gap:.6f}"
                        )
                        pixel_exact=True

                    # Existing conservative override for non-rune families.
                    if (not rune_pixel_rescue and not pixel_agrees and pixel_exact and
                        pixel_best[0] <= 0.0065 and pixel_gap >= 0.0009):
                        top=[pixel_best]+[x for x in top if x[1] is not pixel_best[1]]
                        self.log.insert(
                            "end",
                            f"PIXEL OVERRIDE v6.29 r{item['row']:02d}c{item['col']:02d}: "
                            f"{pixel_best[1].get('name','?')} d={pixel_best[0]:.6f} gap={pixel_gap:.6f}"
                        )
                        pixel_exact=True
            except Exception:
                pixel_exact=False

            # v5.96: canonical Charm rescue is independent of the economy matcher.
            # The 12 base icons are shipped locally, so network/API availability
            # cannot prevent normal/magic Charms from being recognized.
            if charm_best is not None and charm_best[0] <= 0.1450:
                cname=charm_best[1]
                cref={
                    "name":cname, "type":"Charms",
                    "primary_value":None, "icon_file_name":"",
                    "icon_url":"", "base_charm":True,
                    "price_exempt":True
                }
                top=[(charm_best[0],cref)]+[x for x in top if x[1].get("name")!=cname]
                self.log.insert(
                    "end",
                    f"Charm SPECIAL v5.96 r{item['row']:02d}c{item['col']:02d}: "
                    f"{cname} d={charm_best[0]:.5f}"
                )

            # If the local special icon is a very strong match, inject a
            # synthetic reference record. This avoids loosening acceptance for
            # any other Delirium item.
            if special_best is not None and special_best[0] <= 0.080:
                sname=special_best[1]
                if sname.lower()=="ancient concentrated liquid isolation":
                    sref={
                        "name":sname, "type":"Delirium",
                        "primary_value":None, "icon_file_name":"",
                        "icon_url":""
                    }
                    top=[(special_best[0],sref)]+[x for x in top if x[1].get("name")!=sname]
                    self.log.insert("end",
                        f"Special v5.96 icon rescue r{item['row']:02d}c{item['col']:02d}: "
                        f"{sname} d={special_best[0]:.5f} accepted=True")

            # v6.29: supervised same-slot seed.  A distance <= 0.105 is
            # required; otherwise the seed is ignored so a changed stash does
            # not inherit an old label merely because the coordinate matches.
            stash_seed_forced=False
            stash_seed_vetoed=False
            # v6.29: an old supervised seed may itself have been learned from a
            # wrong Rune assignment. Never let such a non-Rune seed override a
            # strong direct Rune match. This specifically fixes the former
            # Medved's Crest -> Lesser Inspiration collisions.
            seed_is_non_rune = bool(stash_seed_best and "Rune" not in stash_seed_best[1])
            seed_is_confirmed_absent = bool(stash_seed_best and
                                            str(stash_seed_best[1]).strip() in CONFIRMED_ABSENT_NAMES)
            if (stash_seed_best is not None and stash_seed_best[0] <= 0.105 and
                not seed_is_confirmed_absent and
                not (seed_is_non_rune and rune_pixel_rescue)):
                sname=stash_seed_best[1]
                
                # v6.29: supervised seed class is explicit.  Unique charms such as
                # Breath of the Mountains do not end in "Charm", so name-based
                # suffix inference is not sufficient here.
                if "Rune" in sname or "Aldur" in sname:
                    seed_type="Runes"
                elif sname in {"Breath of the Mountains"}:
                    seed_type="Charms"
                elif sname.endswith("Charm"):
                    seed_type="Charms"
                elif "Verisium" in sname or "Crest of" in sname:
                    seed_type="Verisium"
                else:
                    seed_type="Expedition"
                sref={"name":sname,"type":seed_type,"primary_value":None,"icon_file_name":"","icon_url":""}
                top=[(stash_seed_best[0],sref)]+[x for x in top if x[1].get("name")!=sname]
                stash_seed_forced=True
                self.log.insert("end", f"STASH SEED v6.29 r{item['row']:02d}c{item['col']:02d}: {sname} d={stash_seed_best[0]:.5f} forced=True supervised=True")
            elif (stash_seed_best is not None and seed_is_confirmed_absent):
                stash_seed_vetoed=True
                self.log.insert(
                    "end",
                    f"STASH SEED VETO v6.29 r{item['row']:02d}c{item['col']:02d}: "
                    f"confirmed_absent={stash_seed_best[1]} d={stash_seed_best[0]:.5f}"
                )
            elif (stash_seed_best is not None and seed_is_non_rune and rune_pixel_rescue):
                stash_seed_vetoed=True
                self.log.insert(
                    "end",
                    f"STASH SEED VETO v6.29 r{item['row']:02d}c{item['col']:02d}: "
                    f"seed={stash_seed_best[1]} d={stash_seed_best[0]:.5f} "
                    f"pixel={pixel_best[1].get('name','?')} d={pixel_best[0]:.6f}"
                )

            d1=top[0][0] if top else 1.0
            d2=top[1][0] if len(top)>1 else 1.0
            gap=d2-d1
            ratio=(d2/d1) if d1>1e-9 else 999.0

            special_forced=(bool(top) and
                            top[0][1].get("name","").strip().lower()==
                            "ancient concentrated liquid isolation" and
                            special_best is not None and
                            special_best[0] <= 0.080)

            # v5.65: use the poe.ninja reference TYPE as a second plausibility
            # signal. An icon should normally compete with references from its
            # own item family. This prevents a Delirium liquid from becoming an
            # Omen merely because their colors/shapes happen to be close.
            top_type=top[0][1].get("type","") if top else ""
            top_name=top[0][1].get("name","") if top else ""
            top_rune_tier=rune_tier(top_name) if top_type == "Runes" else "none"
            top_family=matcher_family(top_type)
            same_type=[x for x in top[:12] if matcher_family(x[1].get("type",""))==top_family]
            other_type=[x for x in top[:12] if matcher_family(x[1].get("type",""))!=top_family]

            # If the best candidate's family has no meaningful support nearby,
            # and another family is close, reject rather than force a match.
            # Charms and UniqueCharms intentionally share the same visual family.
            type_supported=len(same_type)>=2
            best_same=same_type[0][0] if same_type else 1.0
            best_other=other_type[0][0] if other_type else 1.0
            cross_type_ambiguous=(
                bool(other_type) and
                (best_other-best_same <= 0.010 or
                 best_other <= best_same*1.10)
            )

            # v5.65: family-specific acceptance.
            # Delirium liquids are visually close and primarily differentiated
            # by color, so allow a slightly larger distance when there is
            # support from another nearby Delirium reference. Other families
            # retain the stricter generic rule.
            is_delirium=(top_type == "Delirium")
            delirium_support=len(same_type)>=2
            accept_reason="none"
            if stash_seed_forced:
                accepted=True
                accept_reason="stash_seed_exact"
            elif atlas_exact:
                accepted=True
                accept_reason="visual_atlas_exact"
            elif pixel_exact:
                accepted=True
                accept_reason="pixel_exact"
            elif special_forced:
                accepted=True
                accept_reason="special_forced"
            elif top_type in ("Runes", "Idols"):
                # v5.83: Rune/Idol stash expansion. These icons are much more
                # visually similar to one another than the economy matcher
                # threshold of 0.080 allows. Keep the relaxed rule strictly
                # inside the same API family and require either a clear lead
                # or two nearby references from that same family. This avoids
                # turning visually similar Essences/Fragments into Runes.
                same_family_top=(
                    len(top) >= 2 and
                    top[0][1].get("type","") == top_type and
                    top[1][1].get("type","") == top_type
                )
                # v6.29: standard Rune support must come from the SAME
                # upgrade family, not merely from another Rune of the same
                # tier. The old rule let two unrelated Lesser Runes support
                # one another, which was a major source of random
                # Lesser/Normal/Greater assignments.
                if top_type == "Runes" and top_rune_tier != "special":
                    top_family_name=rune_family(top[0][1].get("name","")) if top else ""
                    family_refs=[x for x in top[:12]
                                 if x[1].get("type","")=="Runes" and
                                    rune_family(x[1].get("name",""))==top_family_name]
                    same_family_top=(len(family_refs)>=2)
                family_gap_ok=(gap >= 0.0015 or ratio >= 1.020 or same_family_top)
                family_cross_ok=(not cross_type_ambiguous or best_same <= best_other)
                # Family gate v5.96: a Rune/Idol candidate must normally have
                # support from a second reference of the same family. A single
                # isolated Bear Idol/Boar Idol match is not enough to classify an
                # arbitrary equipment/other-item icon as an Idol. Extremely close
                # matches remain allowed as a safety valve.
                strong_single=(d1 <= 0.0750 and not cross_type_ambiguous)
                mutual_ok=(reverse_rank <= 3)
                pixel_safety=(pixel_exact and pixel_best is not None and pixel_best[0] <= 0.0022)
                accepted=(
                    d1 <= 0.1600 and
                    (same_family_top or strong_single) and
                    family_gap_ok and
                    family_cross_ok and
                    (mutual_ok or pixel_safety or d1 <= 0.0720)
                )
                if accepted:
                    self.log.insert(
                        "end",
                        f"Rune/Idol v6.29 rescue r{item['row']:02d}c{item['col']:02d}: "
                        f"{top[0][1].get('name','?')} type={top_type} d={d1:.5f} "
                        f"gap={gap:.5f} reverse={reverse_rank} accepted=True"
                    )
                if accepted:
                    accept_reason="rune_idol_family"
            elif top_family == "Charms":
                # v5.96: Charm bases are canonical visual references. A normal
                # or magic charm only needs one strong base-icon match; requiring
                # two Charm references was wrong because a stash may contain only
                # one rarity/base variant. Unique charms remain in the same visual
                # family and can still win when their own icon is the best match.
                charm_same=[x for x in top[:12] if matcher_family(x[1].get("type",""))=="Charms"]
                charm_base=[x for x in charm_same if x[1].get("base_charm")]
                charm_supported=len(charm_same)>=2
                canonical_base=(bool(charm_base) and charm_base[0][0] <= 0.1450)
                accepted=(
                    d1 <= 0.1600 and
                    (canonical_base or charm_supported or (d1 <= 0.0800 and not cross_type_ambiguous)) and
                    (not cross_type_ambiguous or best_same <= best_other)
                )
                if accepted:
                    self.log.insert(
                        "end",
                        f"Charm {CHARM_REF_VERSION} rescue r{item['row']:02d}c{item['col']:02d}: "
                        f"{top[0][1].get('name','?')} [{top_type}] d={d1:.5f} "
                        f"canonical_base={canonical_base} accepted=True"
                    )
                if accepted:
                    accept_reason="charm_family"
            elif is_delirium:
                # Delirium liquids are intentionally close in icon appearance.
                # If the two strongest candidates are both Delirium, accept a
                # slightly smaller lead; the interior-color signature is the
                # primary discriminator. Cross-family candidates still block
                # the relaxed rule.
                same_delirium_top = (
                    len(top) >= 2 and
                    top[0][1].get("type","") == "Delirium" and
                    top[1][1].get("type","") == "Delirium"
                )
                accepted=(
                    d1 <= 0.2250 and
                    delirium_support and
                    (
                        gap >= 0.0040 or
                        ratio >= 1.020 or
                        same_delirium_top
                    ) and
                    (not cross_type_ambiguous or best_same <= best_other)
                )
                if accepted:
                    accept_reason="delirium_family"
            else:
                # Simulacrum Splinter is a special fragment case. In the
                # 20-item Delirium test it was consistently the best named
                # candidate, but was rejected because a different family was
                # almost equally close. Accept this exact reference when its
                # visual distance is reasonably close. This is intentionally
                # name-specific so other Fragments are not made permissive.
                is_simulacrum_splinter=(
                    bool(top) and
                    top[0][1].get("name","").strip().lower()=="simulacrum splinter"
                )
                # v5.83: two Delirium references still need a controlled
                # family-specific rescue. The reference may be present just
                # outside the generic top-5 even though it is the visually
                # correct PoE2 icon. Promote it only when the exact named
                # reference is close enough to the best generic candidate.
                special_target=None
                special_names={
                    "simulacrum splinter",
                    "ancient concentrated liquid isolation",
                }
                for cd,cr in best[:20]:
                    nm=cr.get("name","").strip().lower()
                    if nm in special_names:
                        special_target=(cd,cr)
                        break
                if (special_target is not None and
                    special_target[0] <= 0.34 and
                    special_target[0] <= d1 + 0.045):
                    # Put the exact special reference first so downstream
                    # quantity/value aggregation uses its real item name.
                    if top and top[0][1] is not special_target[1]:
                        top=[special_target]+[x for x in top if x[1] is not special_target[1]]
                    d1=top[0][0]
                    if len(top)>1:
                        d2=top[1][0]
                        gap=d2-d1
                        ratio=(d2/d1) if d1>1e-9 else 999.0
                    accepted=True
                    accept_reason="named_special_rescue"
                    if special_target[1].get("name","").strip().lower()=="simulacrum splinter":
                        self.log.insert("end",
                            f"Special v5.96 Simulacrum Splinter rescue r{item['row']:02d}c{item['col']:02d}: "
                            f"d={d1:.5f} best_generic={special_target[0]:.5f} accepted=True")
                    else:
                        self.log.insert("end",
                            f"Special v5.96 Ancient Concentrated Liquid Isolation rescue r{item['row']:02d}c{item['col']:02d}: "
                            f"d={d1:.5f} best_generic={special_target[0]:.5f} accepted=True")
                elif is_simulacrum_splinter:
                    accepted=(d1 <= 0.3400)
                    if accepted:
                        accept_reason="simulacrum_splinter"
                elif top and top[0][1].get("name","").strip().lower()=="ancient concentrated liquid isolation":
                    accepted=(d1 <= 0.3400)
                    if accepted:
                        accept_reason="ancient_isolation"
                else:
                    # v5.96 Family + Margin Guard:
                    # A generic reference must now be both a reasonably close
                    # visual match AND clearly ahead of its runner-up.  The old
                    # rule was permissive enough that an item absent from the
                    # stash could still become a high-value false positive just
                    # because it was the least-bad reference.  Tighten only the
                    # generic path; all family-specific rescues above remain
                    # unchanged.
                    generic_distance_ok = d1 <= 0.0680
                    generic_margin_ok = (gap >= 0.0050 or ratio >= 1.090)
                    generic_family_ok = (type_supported or not cross_type_ambiguous)
                    accepted=(generic_distance_ok and
                              generic_margin_ok and
                              generic_family_ok)
                    if accepted:
                        accept_reason="generic_guard"
                    if accepted:
                        self.log.insert(
                            "end",
                            f"GENERIC GUARD v5.96 r{item['row']:02d}c{item['col']:02d}: "
                            f"{top[0][1].get('name','?')} [{top_type}] "
                            f"d={d1:.5f} gap={gap:.5f} ratio={ratio:.3f} accepted=True"
                        )
                    elif top and d1 <= 0.1000:
                        self.log.insert(
                            "end",
                            f"GENERIC REJECT v5.96 r{item['row']:02d}c{item['col']:02d}: "
                            f"{top[0][1].get('name','?')} [{top_type}] "
                            f"d={d1:.5f} gap={gap:.5f} ratio={ratio:.3f} "
                            f"family_ok={generic_family_ok}"
                        )

            # Diagnostic output: show the top candidates including their
            # reference family. This is intentionally read-only.
            cand_text=[]
            for idx,(cd,cr) in enumerate(top[:3],1):
                cand_text.append(
                    f"#{idx} {cr.get('name','?')} [{cr.get('type','?')}] d={cd:.5f}"
                )
            if cross_type_ambiguous and top:
                self.log.insert(
                    "end",
                    f"Type ambiguity r{item['row']:02d}c{item['col']:02d}: "
                    f"best={top[0][1].get('name','?')} [{top_type}] "
                    f"best_same={best_same:.5f} best_other={best_other:.5f}"
                )
            if top and top[0][1].get("name","").strip().lower()=="simulacrum splinter":
                self.log.insert(
                    "end",
                    f"Simulacrum Splinter rule r{item['row']:02d}c{item['col']:02d}: "
                    f"d={d1:.5f} accepted={accepted}"
                )
            if top and top_type=="Delirium" and d1 <= 0.0950:
                self.log.insert(
                    "end",
                    f"Delirium rule r{item['row']:02d}c{item['col']:02d}: "
                    f"support={delirium_support} d={d1:.5f} "
                    f"gap={gap:.5f} accepted={accepted} threshold=0.225"
                )
            self.log.insert(
                "end",
                f"Match r{item['row']:02d}c{item['col']:02d}: "
                + " | ".join(cand_text)
                + f" | accepted={'YES' if accepted else 'NO'}"
            )
            # v5.96 diagnostic: make the decision path explicit. This is
            # read-only and does not alter matching. It is intentionally
            # emitted for every occupied slot so false positives can be
            # traced back to the exact reference and acceptance rule.
            diag_parts=[]
            for idx,(cd,cr) in enumerate(top[:5],1):
                diag_parts.append(
                    f"#{idx}={cr.get('name','?')}[{cr.get('type','?')}]/{cd:.5f}"
                )
            self.log.insert(
                "end",
                f"MATCH DIAG v5.96 r{item['row']:02d}c{item['col']:02d}: "
                f"route={accept_reason} d1={d1:.5f} d2={d2:.5f} "
                f"gap={gap:.5f} ratio={ratio:.3f} | "
                + " | ".join(diag_parts)
            )
            final_name = top[0][1].get("name", "?") if top else "?"
            final_type = top[0][1].get("type", "?") if top else "?"
            self.log.insert(
                "end",
                f"DIAG DECISION v6.29 r{item['row']:02d}c{item['col']:02d}: "
                f"final={final_name}[{final_type}] accepted={accepted} "
                f"route={accept_reason} generic_best="
                f"{best[0][1].get('name','?') if best else '?'} "
                f"pixel_best={pixel_best[1].get('name','?') if pixel_best else '?'} "
                f"pixel_d={(pixel_best[0] if pixel_best else 9.0):.6f}"
            )
            results.append({
                "row":item["row"],"col":item["col"],
                "accepted":accepted,
                "confidence":{"distance":float(d1),
                              "second_distance":float(d2),
                              "pixel_exact":bool(pixel_exact),
                              "atlas_exact":bool(atlas_exact),
                              "gap":float(gap),"ratio":float(ratio),
                              "top_type":top_type,
                              "type_supported":type_supported,
                              "cross_type_ambiguous":cross_type_ambiguous,
                              "reverse_rank":int(reverse_rank)},
                "matches":[
                    {"distance":float(d),"name":r["name"],"type":r["type"],
                     "primary_value":r.get("primary_value"),
                     "max_volume_currency":r.get("max_volume_currency"),
                     "max_volume_rate":r.get("max_volume_rate"),
                     "icon_file":r.get("icon_file",""),
                     "icon_file_name":r.get("icon_file_name","")}
                    for d,r in top]
            })

        # v6.29: local visual consensus for BOTH rejected and weakly accepted slots.
        # A manually organised stash may contain the same item several times
        # with different stack quantities.  If one slot is a strong, independent
        # reference match and another slot is visually almost identical but was
        # assigned a different name, prefer the strong seed.  The old code only
        # rescued rejected slots, so false-positive accepted matches could survive.
        try:
            icon_by_rc={(x["row"],x["col"]):x for x in icons}
            seeds=[]
            for rr in results:
                if not rr.get("accepted") or not rr.get("matches"):
                    continue
                topm=rr["matches"][0]
                conf=rr.get("confidence",{})
                d=float(conf.get("distance",1.0))
                gap=float(conf.get("gap",0.0))
                typ=str(topm.get("type", ""))
                # Only strong seeds; Rune/Idol can tolerate a little more
                # because their glyphs share a visual family.
                seed_limit=0.105 if typ in ("Runes","Idols") else 0.090
                if d > seed_limit:
                    continue
                icon=icon_by_rc.get((rr["row"],rr["col"]))
                if not icon:
                    continue
                try:
                    with Image.open(icon["icon_clean"]) as im:
                        seeds.append((rr,im.copy(),topm))
                except Exception:
                    pass

            local_rescued=0
            local_corrected=0
            for rr in results:
                icon=icon_by_rc.get((rr["row"],rr["col"]))
                if not icon or not seeds:
                    continue
                try:
                    with Image.open(icon["icon_clean"]) as qim:
                        candidates=[]
                        for seed_rr,sim,sm in seeds:
                            if seed_rr["row"]==rr["row"] and seed_rr["col"]==rr["col"]:
                                continue
                            # Do not propagate across unrelated item families.
                            cur_type=str((rr.get("matches") or [{}])[0].get("type", ""))
                            seed_type=str(sm.get("type", ""))
                            if matcher_family(cur_type) != matcher_family(seed_type):
                                continue
                            dd=self.local_icon_distance(qim,sim)
                            if dd <= 0.0025:
                                candidates.append((dd,sm,seed_rr))
                        if not candidates:
                            continue
                        candidates.sort(key=lambda x:x[0])
                        from collections import Counter
                        names=Counter(c[1].get("name", "?") for c in candidates)
                        best_name,best_count=names.most_common(1)[0]
                        best=[c for c in candidates if c[1].get("name", "?")==best_name]
                        # v6.29: a single exceptionally strong visual seed is
                        # enough when the icon is essentially pixel-identical.
                        # This matters for uniques that occur only once in a
                        # stash: the old rule required two matching seeds unless
                        # the distance was extremely tiny.  Keep the relaxed
                        # path deliberately tight so it cannot become a generic
                        # fuzzy matcher.
                        singleton_exact = (
                            len(candidates) == 1 and
                            candidates[0][0] <= 0.00095
                        )
                        if not (best_count >= 2 or candidates[0][0] <= 0.00065 or singleton_exact):
                            continue
                        src=best[0][1]
                        current_name=(rr.get("matches") or [{}])[0].get("name","?")
                        if not rr.get("accepted"):
                            rr["accepted"]=True
                            rr["matches"]=[dict(src)] + [m for m in rr["matches"] if m.get("name")!=src.get("name")]
                            rr["confidence"]["local_consensus"]=True
                            rr["confidence"]["local_distance"]=float(best[0][0])
                            local_rescued += 1
                            self.log.insert(
                                "end",
                                f"LOCAL CONSENSUS v6.29 RESCUE r{rr['row']:02d}c{rr['col']:02d}: "
                                f"{best_name} d={best[0][0]:.6f} seeds={best_count}"
                            )
                        elif current_name != best_name:
                            # Only correct an accepted result when the visual
                            # evidence is exceptionally strong and the current
                            # match is materially weaker. This is the important
                            # v6.29 change: it fixes accepted false positives
                            # without turning the consensus into a free matcher.
                            cur_d=float(rr.get("confidence",{}).get("distance",1.0))
                            if best[0][0] <= 0.0012 or cur_d >= 0.0700:
                                rr["matches"]=[dict(src)] + [m for m in rr["matches"] if m.get("name")!=src.get("name")]
                                rr["confidence"]["local_consensus_correction"]=True
                                rr["confidence"]["local_distance"]=float(best[0][0])
                                local_corrected += 1
                                self.log.insert(
                                    "end",
                                    f"LOCAL CONSENSUS v6.29 CORRECT r{rr['row']:02d}c{rr['col']:02d}: "
                                    f"{current_name} -> {best_name} d={best[0][0]:.6f} "
                                    f"current_d={cur_d:.6f} seeds={best_count}"
                                )
                except Exception:
                    continue
            if local_rescued or local_corrected:
                self.log.insert(
                    "end",
                    f"LOCAL CONSENSUS v6.29: rescued={local_rescued} corrected={local_corrected}"
                )
        except Exception as ex:
            self.log.insert("end", f"LOCAL CONSENSUS v6.29 ERROR: {ex!r}")

        self.learn_visual_atlas(results, icons)

        accepted_count=sum(1 for r in results if r.get("accepted"))
        self.log.insert(
            "end",
            f"Matcher output: {len(results)} icon matches generated; "
            f"accepted={accepted_count}; uncertain={len(results)-accepted_count}."
        )
        self.root.update()
        return results


    def analyze(self,stash):
        w,h=stash.size
        folder=os.path.join(SLOT_DIR,f"capture_{self.counter:03d}")
        icon_folder=os.path.join(folder,"icons")
        clean_folder=os.path.join(folder,"icons_clean")
        os.makedirs(icon_folder,exist_ok=True)
        os.makedirs(clean_folder,exist_ok=True)

        # Keep the raw stash immutable for all matching and quantity OCR.
        # Debug overlays are rendered on a separate copy only.
        raw_stash=stash.copy()
        out=raw_stash.copy()
        d=ImageDraw.Draw(out)
        data=[]
        icons=[]

        for r in range(12):
            for c in range(12):
                x1=round(c*w/12); x2=round((c+1)*w/12)
                y1=round(r*h/12); y2=round((r+1)*h/12)
                # ALWAYS crop from raw_stash, never from the debug image.
                slot=raw_stash.crop((x1,y1,x2,y2))
                slot_path=os.path.join(folder,f"r{r+1:02d}_c{c+1:02d}.png")
                slot.save(slot_path)

                pad=max(2,round(min(slot.size)*.08))
                inner=slot.crop((pad,pad,slot.width-pad,slot.height-pad)).convert("RGB")
                pix=list(inner.getdata()); n=len(pix)
                mean=sum(sum(p)/3 for p in pix)/n
                bright=sum(1 for rr,gg,bb in pix if max(rr,gg,bb)>55)/n
                occupied=(mean>25 and bright>.12)

                if occupied:
                    # v2.2 cropped 10%-90%, which clipped several PoE2 icons.
                    # v2.3 keeps almost the complete slot. The quantity text
                    # is retained in the RAW image and handled separately.
                    inset=max(1,round(min(slot.size)*0.015))
                    icon=slot.crop((
                        inset,inset,
                        slot.width-inset,slot.height-inset
                    ))
                    icon=icon.resize((192,192),Image.Resampling.LANCZOS)

                    icon_path=os.path.join(
                        icon_folder,f"r{r+1:02d}_c{c+1:02d}.png")
                    icon.save(icon_path)

                    # Clean variant: keep the complete icon but suppress only
                    # the usual stack-number corner. This is for image matching;
                    # the RAW variant remains available for diagnostics.
                    clean=icon.copy()
                    cd=ImageDraw.Draw(clean)
                    corner=round(clean.width*0.22)
                    # Sample the dark background from the upper-left edge.
                    bg=clean.getpixel((2,2))
                    cd.rectangle((0,0,corner,round(clean.height*0.20)),fill=bg)
                    clean_path=os.path.join(
                        clean_folder,f"r{r+1:02d}_c{c+1:02d}.png")
                    clean.save(clean_path)

                    icons.append({
                        "row":r+1,"col":c+1,
                        "slot":slot_path,
                        "icon":icon_path,
                        "icon_clean":clean_path
                    })

                d.rectangle(
                    (x1+2,y1+2,x2-2,y2-2),
                    outline=(40,255,80) if occupied else (255,70,70),
                    width=2
                )
                # Put the scan coordinate in the upper-right corner so it cannot
                # overlap PoE2's white stack quantity in the upper-left corner.
                coord=f"{r+1},{c+1}"
                bbox=d.textbbox((0,0),coord)
                tw=bbox[2]-bbox[0]
                d.text((x2-tw-4,y1+2),coord,fill=(255,255,0))
                if occupied:
                    d.text((x2-28,y2-18),"ICON",fill=(255,255,255))

                data.append((r+1,c+1,occupied))

        # Contact sheet uses the RAW, almost-full icon crops.
        thumb_w=180; thumb_h=205; cols=5
        rows=max(1,(len(icons)+cols-1)//cols)
        sheet=Image.new("RGB",(cols*thumb_w,rows*thumb_h),(20,20,20))
        sd=ImageDraw.Draw(sheet)
        for i,item in enumerate(icons):
            im=Image.open(item["icon"]).convert("RGB")
            im.thumbnail((165,165),Image.Resampling.LANCZOS)
            x=(i%cols)*thumb_w+7
            y=(i//cols)*thumb_h+5
            sheet.paste(im,(x,y))
            sd.text((x,y+170),
                    f'{item["row"]},{item["col"]}',
                    fill=(255,255,0))
        sheet_path=os.path.join(folder,"icon_contact_sheet.png")
        sheet.save(sheet_path)

        manifest={
            "capture":self.counter,
            "stash_size":[w,h],
            "grid":[12,12],
            "icon_crop":"1.5% inset, almost complete slot",
            "analysis_source":"raw_stash_unmodified",
            "debug_overlay":"coordinate labels upper-right only on debug image",
            "icons":icons,
            "contact_sheet":sheet_path
        }
        with open(os.path.join(folder,"manifest.json"),"w",encoding="utf-8") as f:
            json.dump(manifest,f,indent=2)

        return out,data,folder


    # ---------- Multi-tab / current league ----------
    def reset_session(self):
        self.session_items={}
        self.session_hashes=set()
        self.session_tab_count=0
        self.f8_count=0
        # Create a unique evaluation marker so a log can never be mistaken for
        # a previous run, even when the application directory is on OneDrive.
        self.evaluation_id=time.strftime("%Y%m%d-%H%M%S")
        removed=self.cleanup_scan_output()
        self.counter=1
        # A NEW EVALUATION is a hard diagnostic boundary: old messages must not
        # survive into the next report.
        self.log.delete("1.0","end")
        self.log.insert("end", f"NEW EVALUATION v6.29 | eval={self.evaluation_id} | screenshot folder cleaned ({removed} old PNGs removed).")
        self.log.insert("end", "F8 CAPTURE ARMED | no screenshot is created until SCAN (F8) is actually executed.")
        self.log.insert("end", f"EVALUATION READY v6.29 | eval={self.evaluation_id} | previous process log cannot survive this boundary.")
        # Clear the visible result table as well. Otherwise a NEW EVALUATION
        # shows the previous Top20 while the counters already say 0 Tabs / 0 items.
        self.render_top20()
        self.status.set("New evaluation started. Screenshot-Ordner ist leer. Erst F8 erzeugt neue Bilder.")

    def get_current_league(self):
        url="https://poe.ninja/poe2/api/economy/leagues"
        data,status,raw_len=self.api_get_json(url)
        leagues=data if isinstance(data,list) else data.get("leagues",[])
        if not leagues:
            raise RuntimeError("poe.ninja liefert keine aktive PoE2-Liga.")
        league=leagues[0]
        self.league_id=league.get("id")
        self.league_name=league.get("name") or self.league_id
        if not self.league_id:
            raise RuntimeError("Aktuelle PoE2-Liga hat keine ID.")
        return self.league_id,self.league_name

    def _load_digit_templates(self):
        if hasattr(self,"digit_templates"):
            return self.digit_templates
        p=os.path.join(APP,"digit_templates.json")
        try:
            with open(p,encoding="utf-8") as f:
                raw=json.load(f)
            self.digit_templates={
                d:[[int(x) for x in row] for row in v]
                for d,v in raw.items()
            }
        except Exception:
            self.digit_templates={}
        return self.digit_templates



    def _load_quantity_number_templates_67(self):
        if hasattr(self, "_quantity_number_templates_67"):
            return self._quantity_number_templates_67
        out={}
        p=os.path.join(APP,"quantity_number_templates_67.json")
        try:
            with open(p,encoding="utf-8") as f:
                raw=json.load(f)
            for k,arrs in raw.items():
                out[str(k)]=[np.asarray(a,dtype=np.uint8) for a in arrs]
        except Exception:
            out={}
        self._quantity_number_templates_67=out
        return out

    def _direct_number_quantity_67(self, slot_path, liquid=False):
        """Template-match the visible PoE2 quantity at the same 67x67 scale
        as the scanner debug grid. This path is deliberately independent of
        item matching and of the old candidate/OCR code.
        """
        try:
            im=Image.open(slot_path).convert("RGB").resize((67,67),Image.Resampling.LANCZOS)
        except Exception:
            return None
        tm=self._load_quantity_number_templates_67()
        if not tm:
            return None

        best_by_val={}
        # Exact region where the white stack number appears in the supplied
        # scanner image: upper-left, before the yellow coordinate label.
        for th in (120,130,150,170,190,210):
            a=np.asarray(im,dtype=np.uint8)
            roi=a[3:24,3:31]
            mx=roi.max(2); mn=roi.min(2)
            m=((mx>=th)&((mx-mn)<=120)).astype(np.uint8)
            for val,arrs in tm.items():
                if liquid and (not val.isdigit() or not (1<=int(val)<=10)):
                    continue
                for t in arrs:
                    if t.shape!=m.shape:
                        continue
                    aa=m>0; bb=t>0
                    inter=int(np.logical_and(aa,bb).sum())
                    union=int(np.logical_or(aa,bb).sum())
                    if union==0: continue
                    iou=inter/union
                    # Strong penalty when the white-pixel counts differ a lot.
                    size_pen=abs(int(aa.sum())-int(bb.sum()))/max(1,int(bb.sum()))
                    score=iou-0.10*min(size_pen,2.0)
                    prev=best_by_val.get(val)
                    if prev is None or score>prev:
                        best_by_val[val]=score

        if not best_by_val:
            return None

        ranked=sorted(best_by_val.items(), key=lambda x:x[1], reverse=True)
        top_val,top_score=ranked[0]
        second_score=ranked[1][1] if len(ranked)>1 else -1
        # Require a meaningful absolute score and a margin over the runner-up.
        # Multi-digit 231 is also permitted for Simulacrum Splinter.
        margin=top_score-second_score if second_score>=0 else 1.0
        if top_score < 0.42 or margin < 0.035:
            return None

        try:
            self.log.insert("end",
                f"QTY DIRECT v5.83 {os.path.basename(slot_path)}: "
                f"selected={top_val} score={top_score:.3f} margin={margin:.3f}")
        except Exception:
            pass
        return int(top_val), (top_score < 0.55 or margin < 0.07)

    def _special_quantity_468(self, slot_path):
        """Recognize the three PoE2 single glyphs that are easily confused.

        The templates come directly from the user's 67x67 scanner-grid capture.
        This path is intentionally limited to a single compact glyph, so it
        cannot replace a valid multi-digit quantity such as 10 or 263.
        """
        def norm_pad(a):
            a=(a>0).astype(np.uint8)
            ys,xs=np.where(a)
            if len(xs)==0:
                return None
            a=a[ys.min():ys.max()+1,xs.min():xs.max()+1]
            a=np.pad(a,((1,1),(1,1)),constant_values=0)
            return a

        def resize_pad(a,ow=24,oh=32):
            sh,sw=a.shape
            if sh<=0 or sw<=0:
                return np.zeros((oh,ow),dtype=np.uint8)
            scale=min((ow-2)/sw,(oh-2)/sh)
            nw=max(1,int(round(sw*scale))); nh=max(1,int(round(sh*scale)))
            yy=(np.arange(nh)*sh//nh).clip(0,sh-1)
            xx=(np.arange(nw)*sw//nw).clip(0,sw-1)
            r=a[np.ix_(yy,xx)].astype(np.uint8)
            out=np.zeros((oh,ow),dtype=np.uint8)
            x=(ow-nw)//2; y=(oh-nh)//2
            out[y:y+nh,x:x+nw]=r
            return out

        try:
            im=Image.open(slot_path).convert("RGB").resize(
                (67,67),Image.Resampling.LANCZOS)
            with open(os.path.join(APP,"digit_templates_468_clean.json"),encoding="utf-8") as f:
                raw=json.load(f)
            tm={d:np.asarray(v,dtype=np.uint8) for d,v in raw.items()}
        except Exception:
            return None

        a=np.asarray(im,dtype=np.uint8)
        best=None
        # The quantity glyph is the left-most compact component in this lane.
        for th in (150,170,190,210):
            roi=im.crop((2,2,30,25))
            bw=((np.asarray(roi.convert("HSV"),dtype=np.uint8)[:,:,2]>=th) &
                (np.asarray(roi.convert("HSV"),dtype=np.uint8)[:,:,1]<=115)).astype(np.uint8)
            boxes=self._quantity_components_67(bw)
            for b in boxes:
                x0,y0,x1,y1,_=b
                gw=x1-x0; gh=y1-y0
                # 4/6/8 in the supplied PoE2 UI are compact single glyphs.
                if not (3<=gw<=11 and 10<=gh<=19 and x0<=8):
                    continue
                glyph=bw[y0:y1,x0:x1]
                q=resize_pad(norm_pad(glyph))
                if q is None:
                    continue
                scores={}
                for d,t in tm.items():
                    aa=q>0; tt=t>0
                    inter=np.logical_and(aa,tt).sum()
                    union=np.logical_or(aa,tt).sum()
                    if union==0:
                        continue
                    prec=inter/max(1,aa.sum())
                    rec=inter/max(1,tt.sum())
                    f1=2*prec*rec/max(1e-9,prec+rec)
                    scores[d]=0.65*(inter/union)+0.35*f1
                if len(scores)<2:
                    continue
                ranked=sorted(scores.items(),key=lambda x:x[1],reverse=True)
                val,score=ranked[0]
                margin=score-ranked[1][1]
                if score>=0.72 and margin>=0.15:
                    cand=(score,margin,int(val),th,b)
                    if best is None or cand[:2] > best[:2]:
                        best=cand

        if best is None:
            return None
        score,margin,val,th,b=best
        try:
            self.log.insert(
                "end",
                f"QTY SPECIAL v5.83 {os.path.basename(slot_path)}: "
                f"selected={val} score={score:.3f} margin={margin:.3f} "
                f"box={b}"
            )
        except Exception:
            pass
        return val, False

    def _quantity_components_67(self, bw):
        a=(np.asarray(bw,dtype=np.uint8)>0)
        hh,ww=a.shape
        seen=np.zeros((hh,ww),dtype=np.uint8)
        boxes=[]
        for sy in range(hh):
            for sx in range(ww):
                if not a[sy,sx] or seen[sy,sx]:
                    continue
                stack=[(sy,sx)]; seen[sy,sx]=1
                minx=maxx=sx; miny=maxy=sy; area=0
                while stack:
                    y,x=stack.pop(); area+=1
                    minx=min(minx,x); maxx=max(maxx,x)
                    miny=min(miny,y); maxy=max(maxy,y)
                    for dy in (-1,0,1):
                        for dx in (-1,0,1):
                            if dx==0 and dy==0:
                                continue
                            ny=y+dy; nx=x+dx
                            if (0<=ny<hh and 0<=nx<ww and
                                a[ny,nx] and not seen[ny,nx]):
                                seen[ny,nx]=1
                                stack.append((ny,nx))
                bwid=maxx-minx+1; bhei=maxy-miny+1
                if 3<=bwid<=20 and 8<=bhei<=22 and 5<=area<=300:
                    boxes.append(
                        (int(minx),int(miny),int(maxx+1),int(maxy+1),int(area)))
        boxes.sort(key=lambda b:(b[0],b[1]))
        return boxes

    def quantity_from_slot(self, slot_path, liquid=False, max_stack=None):
        """Read PoE2 stack quantity from the raw 192x192 slot image.

        v5.83 uses the real PoE2 quantity glyphs visible in the captured slot
        samples shipped with this build. The scan itself is unchanged: each
        slot is still analyzed exactly as before; only quantity OCR is replaced.
        """
        def validate_qty(result):
            if result is None:
                return None
            q,u=result
            try:
                q=int(q)
            except Exception:
                return (1,True)
            limit = 10 if liquid else (int(max_stack) if max_stack else None)
            if limit and not (1 <= q <= limit):
                try:
                    self.log.insert("end",
                        f"QTY STACK FILTER {os.path.basename(slot_path)}: "
                        f"rejected={q} max={limit}")
                except Exception:
                    pass
                return (1,True)
            return (q,u)

        special = self._special_quantity_468(slot_path)
        if special is not None:
            return validate_qty(special)

        direct = self._direct_number_quantity_67(slot_path, liquid=liquid)
        if direct is not None:
            return validate_qty(direct)

        try:
            im=Image.open(slot_path).convert("RGB")
        except Exception:
            return 1, True
        w,h=im.size
        if w < 20 or h < 20:
            return 1, True

        # Quantity text is in the upper-left lane, but the raw slot crop can be
        # shifted vertically by a few pixels. Scan a generous top-left lane.
        # Scanner-grid slot crops are 67x67. Their quantity glyph sits in the
        # upper-left corner (roughly x=4..25, y=3..22). The old generic fallback
        # started at y=20 and therefore missed most quantities whenever the
        # specialized sample matcher did not fire. Keep the old full-size lanes
        # as a fallback, but explicitly scan the 67x67 upper-left quantity lane.
        if w <= 80 and h <= 80:
            rois=[
                (0,0,min(w,34),min(h,28)),
                (2,2,min(w,40),min(h,32)),
                (0,4,min(w,34),min(h,30)),
                (4,0,min(w,42),min(h,26)),
            ]
        else:
            rois=[
                (0,20,min(w,80),min(h,72)),
                (8,28,min(w,88),min(h,76)),
                (10,35,min(w,90),min(h,75)),
                (12,40,min(w,92),min(h,70)),
            ]

        def norm_pad(a):
            a=(a>0).astype(np.uint8)
            ys,xs=np.where(a)
            if len(xs)==0:
                return None
            a=a[ys.min():ys.max()+1,xs.min():xs.max()+1]
            a=np.pad(a,((1,1),(1,1)),constant_values=0)
            return a

        def resize_pad(a,ow=24,oh=32):
            sh,sw=a.shape
            if sh<=0 or sw<=0:
                return np.zeros((oh,ow),dtype=np.uint8)
            scale=min((ow-2)/sw,(oh-2)/sh)
            nw=max(1,int(round(sw*scale))); nh=max(1,int(round(sh*scale)))
            yy=(np.arange(nh)*sh//nh).clip(0,sh-1)
            xx=(np.arange(nw)*sw//nw).clip(0,sw-1)
            r=a[np.ix_(yy,xx)].astype(np.uint8)
            out=np.zeros((oh,ow),dtype=np.uint8)
            x=(ow-nw)//2; y=(oh-nh)//2
            out[y:y+nh,x:x+nw]=r
            return out

        def mask_from_roi(roi, threshold):
            # OpenCV-free HSV conversion using Pillow's built-in HSV mode.
            # This keeps the program self-contained on a normal Python install.
            hsv=np.asarray(roi.convert("HSV"),dtype=np.uint8)
            h=hsv[:,:,0]; sat=hsv[:,:,1]; v=hsv[:,:,2]
            del h
            # Quantity text is bright and nearly achromatic. This removes most
            # colorful item art without needing any OCR engine.
            return ((v>=threshold)&(sat<=115)).astype(np.uint8)

        def components(bw):
            # Small 8-connected component finder implemented with NumPy/Python;
            # avoids a hard dependency on cv2 while preserving the old box logic.
            a=(np.asarray(bw,dtype=np.uint8)>0)
            hh,ww=a.shape
            seen=np.zeros((hh,ww),dtype=np.uint8)
            boxes=[]
            for sy in range(hh):
                for sx in range(ww):
                    if not a[sy,sx] or seen[sy,sx]:
                        continue
                    stack=[(sy,sx)]; seen[sy,sx]=1
                    minx=maxx=sx; miny=maxy=sy; area=0
                    while stack:
                        y,x=stack.pop(); area+=1
                        if x<minx: minx=x
                        if x>maxx: maxx=x
                        if y<miny: miny=y
                        if y>maxy: maxy=y
                        for dy in (-1,0,1):
                            for dx in (-1,0,1):
                                if dx==0 and dy==0: continue
                                ny=y+dy; nx=x+dx
                                if 0<=ny<hh and 0<=nx<ww and a[ny,nx] and not seen[ny,nx]:
                                    seen[ny,nx]=1; stack.append((ny,nx))
                    bwid=maxx-minx+1; bhei=maxy-miny+1
                    # Real glyph sizes seen in the supplied raw slot crops:
                    # narrow 1 is ~6-8px wide, broad 2/6/9 are ~22-24px wide,
                    # and glyph height is ~15-22px.
                    if 3<=bwid<=30 and 9<=bhei<=28 and 8<=area<=500:
                        if minx<=68 and miny<=48:
                            boxes.append((int(minx),int(miny),int(maxx+1),int(maxy+1),int(area)))
            boxes.sort(key=lambda b:(b[0],b[1]))
            return boxes

        # Build the real-glyph template bank once from the known PoE2 slot
        # samples. These are shape references only; no stack quantities are
        # hardcoded into the scan result.
        if not hasattr(self,"_qty_sample_templates"):
            bank={k:[] for k in "0123456789"}
            sample_defs=[
                (os.path.join(APP,"qty_samples","r01_c01.png"),"9"),
                (os.path.join(APP,"qty_samples","r01_c02.png"),"1"),
                (os.path.join(APP,"qty_samples","r01_c03.png"),"2"),
                (os.path.join(APP,"qty_samples","r01_c04.png"),"6"),
                (os.path.join(APP,"qty_samples","r01_c05.png"),"11"),
                (os.path.join(APP,"qty_samples","r01_c07.png"),"10"),
                (os.path.join(APP,"qty_samples","r01_c11.png"),"3"),
                (os.path.join(APP,"qty_samples","r02_c09.png"),"5"),
                # v5.83: real PoE2 67x67 scanner-grid samples for the two
                # glyphs that were still confused by the generic templates.
                (os.path.join(APP,"qty_samples","r02_c04.png"),"4"),
                (os.path.join(APP,"qty_samples","r08_c02.png"),"8"),
            ]
            def sample_components(path):
                try:
                    arr=Image.open(path).convert("RGB")
                except Exception:
                    return []
                # The original raw slot samples use the stable lane around
                # y=35..72. The v5.83 additions are 67x67 scanner-grid
                # samples, where the quantity is directly in the upper-left.
                small_sample=(arr.width <= 80 or arr.height <= 80)
                if small_sample:
                    lane=arr.crop((2,2,min(arr.width,34),min(arr.height,28)))
                else:
                    lane=arr.crop((8,35,min(arr.width,90),min(arr.height,72)))
                out=[]
                for th in (150,170,190,210):
                    bw=mask_from_roi(lane,th)
                    cs=components(bw)
                    if small_sample and cs:
                        # The 67x67 scanner-grid samples have a smaller
                        # anti-aliased glyph than the raw 192x192 samples.
                        # Keep only the largest upper-left component so white
                        # highlights from the item art cannot become a second
                        # digit.
                        upper=[b for b in cs if b[0] <= 13]
                        cs=sorted(upper or cs,key=lambda b:b[4],reverse=True)[:1]
                    if cs:
                        for b in cs:
                            x0,y0,x1,y1,_=b
                            out.append(bw[y0:y1,x0:x1])
                        if out:
                            return out
                return out
            for path,label in sample_defs:
                cs=sample_components(path)
                if len(label)==1 and cs:
                    bank[label].append(resize_pad(norm_pad(cs[0])))
                elif len(label)==len(cs) and len(label)>1:
                    for d,ch in zip(label,cs):
                        bank[d].append(resize_pad(norm_pad(ch)))
            # A second pass specifically extracts the clipped 0 from the 10 sample.
            try:
                p=os.path.join(APP,"qty_samples","r01_c07.png")
                arr=Image.open(p).convert("RGB")
                lane=arr.crop((8,35,min(arr.width,90),min(arr.height,72)))
                bw=mask_from_roi(lane,190)
                cs=[]
                for b in components(bw):
                    x0,y0,x1,y1,_=b
                    cs.append((x0,y0,x1,y1))
                cs.sort()
                if len(cs)>=2:
                    # The second glyph in the 10 sample is the zero.
                    x0,y0,x1,y1=cs[-1]
                    bank["0"].append(resize_pad(norm_pad(bw[y0:y1,x0:x1])))
            except Exception:
                pass
            # Fall back to the shipped template set for digits without a raw sample.
            try:
                with open(os.path.join(APP,"actual_digit_templates_v2.json"),encoding="utf-8") as f:
                    raw=json.load(f)
                for d,v in raw.items():
                    if not bank.get(str(d)):
                        a=(np.asarray(v,dtype=np.uint8)>0).astype(np.uint8)
                        bank[str(d)].append(a)
            except Exception:
                pass
            self._qty_sample_templates=bank

        def glyph_score(glyph):
            q=resize_pad(norm_pad(glyph))
            if q is None: return None,0.0
            best=(999.0,None)
            for d,arrs in self._qty_sample_templates.items():
                for t in arrs:
                    if t is None: continue
                    aa=q.astype(bool); tt=t.astype(bool)
                    inter=np.logical_and(aa,tt).sum(); union=np.logical_or(aa,tt).sum()
                    if union==0: continue
                    iou=inter/union
                    prec=inter/max(1,aa.sum()); rec=inter/max(1,tt.sum())
                    f1=2*prec*rec/max(1e-9,prec+rec)
                    dist=0.65*(1-iou)+0.35*(1-f1)
                    if dist<best[0]: best=(dist,d)
            if best[1] is None: return None,0.0
            return best[1],max(0.0,1.0-best[0])

        allc=[]
        base=os.path.splitext(os.path.basename(slot_path))[0]
        for ri,box in enumerate(rois):
            roi=im.crop(box)
            for th in (170,190,210,225):
                bw=mask_from_roi(roi,th)
                boxes=components(bw)
                if not boxes:
                    continue
                # Merge close components at the same baseline only if they are
                # clearly part of one quantity string. Do not merge an item blob.
                groups=[]
                for b in boxes:
                    if not groups:
                        groups.append([b]); continue
                    prev=groups[-1][-1]
                    gap=b[0]-prev[2]
                    base_diff=abs(b[3]-prev[3])
                    if gap<=8 and base_diff<=4:
                        groups[-1].append(b)
                    else:
                        groups.append([b])
                for grp in groups:
                    if len(grp)>3: continue
                    chars=[]; scores=[]
                    for x0,y0,x1,y1,_ in grp:
                        d,sc=glyph_score(bw[y0:y1,x0:x1])
                        if d is None or sc<0.48:
                            chars=[]; break
                        chars.append(d); scores.append(sc)
                    if not chars: continue
                    txt=''.join(chars)
                    if txt.startswith('0'): continue
                    try: val=int(txt)
                    except Exception: continue
                    maxv=(10 if liquid else (int(max_stack) if max_stack else 999))
                    if not (1<=val<=maxv):
                        continue
                    span=grp[-1][2]-grp[0][0]
                    if span>82: continue
                    if max(b[1] for b in grp)-min(b[1] for b in grp)>5:
                        continue
                    if max(b[3] for b in grp)-min(b[3] for b in grp)>6:
                        continue
                    score=sum(scores)/len(scores)
                    allc.append((score,val,ri,th,txt,grp))

        grouped={}
        for c in allc:
            grouped.setdefault(c[1],[]).append(c)
        ranked=[]
        for val,arr in grouped.items():
            best=max(arr,key=lambda x:x[0]); freq=len(arr)
            # Consistency across thresholds/ROIs is still the main confidence signal.
            score=min(0.995,0.45+0.10*min(freq,5)+0.30*best[0])
            ranked.append((score,val,best,freq))
        # When several candidates exist, prefer a multi-digit candidate only when
        # it is geometrically plausible and not substantially weaker than a single digit.
        ranked.sort(key=lambda x:(x[0],x[3],len(str(x[1]))),reverse=True)

        try:
            if not getattr(self,"_qty_engine_banner",False):
                self.log.insert('end','QUANTITY ENGINE v6.29: real-slot glyph templates + stack-size validation')
                self._qty_engine_banner=True
        except Exception: pass
        try:
            if ranked:
                self.log.insert('end',f"QTY CANDIDATES v6.29 {base}: "+"; ".join(
                    f"{v} score={sc:.2f} roi={b[2]} thr={b[3]} reps={freq} boxes={b[5]}"
                    for sc,v,b,freq in ranked[:10]))
            else:
                self.log.insert('end',f"QTY CANDIDATES v6.29 {base}: NONE")
        except Exception: pass
        if ranked:
            chosen=ranked[0]
            uncertain=chosen[0]<0.65 or chosen[3]<2
            try:self.log.insert('end',f"QTY RESULT v6.29 {base}: selected={chosen[1]} score={chosen[0]:.2f} reps={chosen[3]}")
            except Exception: pass
            return chosen[1],uncertain
        try:self.log.insert('end',f"QTY RESULT v6.29 {base}: fallback=1")
        except Exception: pass
        return 1,True

    def add_matches_to_session(self, matches, icons):
        icon_map={(x["row"],x["col"]):x for x in icons}
        unknown=0
        qty_fallback=0
        accepted_names=[]
        rejected_names=[]

        for m in matches:
            if not m.get("matches") or not m.get("accepted",False):
                unknown += 1
                if m.get("matches"):
                    rejected_names.append(
                        f"r{m['row']:02d}c{m['col']:02d}="
                        f"{m['matches'][0].get('name','?')}"
                    )
                continue

            best=m["matches"][0]
            accepted_names.append(best.get("name","?"))
            icon=icon_map.get((m["row"],m["col"]))

            # Determine the item class BEFORE quantity OCR.
            # (v5.65 accidentally referenced is_delirium_liquid before
            # assigning it, which aborted rendering of the result table.)
            item_type=str(best.get("type"," ")).lower()
            item_name=str(best.get("name"," ")).lower()
            is_delirium_liquid=(
                item_type=="delirium" and
                ("liquid" in item_name)
            )

            # Simulacrum itself does not stack in PoE2. Every occupied
            # Simulacrum slot is exactly one item; never OCR its artwork as
            # a quantity. Simulacrum Splinter is stackable and therefore
            # continues through the quantity reader.
            is_nonstacking_simulacrum=(item_name == "simulacrum")
            is_nonstacking_charm=(matcher_family(best.get("type","")) == "Charms")
            if is_nonstacking_simulacrum or is_nonstacking_charm:
                qty,uncertain_qty=1,False
            else:
                # Quantity OCR receives ONLY the raw slot file created above.
                qty_source = icon["slot"] if icon else None
                try:
                    self.log.insert("end", f"QTY SOURCE v6.29 {best.get('name','?')}: {qty_source if qty_source else 'MISSING'}")
                except Exception:
                    pass
                max_stack=self.get_stack_size(best)
                qty,uncertain_qty=self.quantity_from_slot(
                    qty_source, liquid=is_delirium_liquid, max_stack=max_stack
                ) if qty_source else (1,True)
                try:
                    self.log.insert(
                        "end",
                        f"QTY STACK META v6.29 {best.get('name','?')}: max={max_stack if max_stack else '?'}"
                    )
                except Exception:
                    pass

            # Delirium liquids stack to a maximum of 10 per slot.
            # Their quantities are summed across all stacks afterwards.
            if is_delirium_liquid and not (1 <= qty <= 10):
                qty,uncertain_qty=1,True
            if uncertain_qty:
                qty_fallback += 1
            # v5.65: keep the quantity algorithm unchanged, but record the
            # visual quantity candidates and selected value for calibration.
            try:
                slot_dbg = icon.get("slot") if icon else None
                self.log.insert(
                    "end",
                    f"QUANTITY DEBUG v6.29 {best.get('name','?')}: "
                    f"selected={qty} uncertain={uncertain_qty} "
                    f"liquid_1_10={is_delirium_liquid} "
                    f"slot={'yes' if slot_dbg is not None else 'no'}"
                )
            except Exception:
                pass

            key=best["name"]
            price_exempt=bool(best.get("price_exempt"))
            if key not in self.session_items:
                self.session_items[key]={
                    "name":key,"quantity":0,
                    "unit_price":None if price_exempt else best.get("primary_value"),
                    "type":best.get("type"),
                    "icon_file":best.get("icon_file",""),
                    "best_distance":best.get("distance"),
                    "price_exempt":price_exempt
                }
            rec=self.session_items[key]
            rec["quantity"] += qty
            if not price_exempt and best.get("primary_value") is not None:
                rec["unit_price"]=best.get("primary_value")
            if price_exempt:
                rec["price_exempt"]=True
            rec["best_distance"]=min(rec.get("best_distance",99),best.get("distance",99))
            self.log.insert(
                "end",
                f"ADDED r{m['row']:02d}c{m['col']:02d}: "
                f"{best.get('name','?')} qty={qty} "
                f"session_total={rec['quantity']}"
            )

        self.log.insert("end",
            f"Match filter: {unknown} uncertain icons ignored, "
            f"{qty_fallback} quantities fell back to 1.")

        # Explicit accounting: accepted matches and aggregated session keys.
        from collections import Counter
        accepted_counter=Counter(accepted_names)
        self.log.insert(
            "end",
            "ACCEPTED ITEMS: " + ", ".join(
                f"{name} x{count}" for name,count in sorted(accepted_counter.items())
            )
        )
        self.log.insert(
            "end",
            "SESSION ITEMS: " + ", ".join(
                f"{name} x{rec['quantity']}"
                for name,rec in sorted(self.session_items.items())
            )
        )
        self.log.insert(
            "end",
            "REJECTED BEST: " + (", ".join(rejected_names) if rejected_names else "none")
        )
        # Show the newest diagnostic information immediately.
        self.root.after_idle(lambda: self.log.see("end"))


    def render_top20(self):
        rows=[]
        for rec in self.session_items.values():
            # Non-unique charms are useful utility items, but are deliberately
            # excluded from the value ranking. Their magic affixes are not
            # relevant to this inventory/top-value view. Unique charms keep
            # their poe.ninja market price and remain fully rankable.
            if rec.get("price_exempt"):
                continue
            try:
                unit=float(rec.get("unit_price") or 0)
                total=unit*rec["quantity"]
            except Exception:
                unit=0; total=0
            rec2=dict(rec); rec2["total_value"]=total
            rows.append(rec2)
        rows.sort(key=lambda x:x["total_value"],reverse=True)

        for child in self.result_inner.winfo_children():
            child.destroy()
        self.result_images=[]

        tk.Label(self.result_inner,
            text=(f"TOP 20  |  {self.session_tab_count} Tabs  |  "
                  f"{len(self.session_items)} unique items  |  League: {self.league_name or '-'}"),
            anchor="w",background="white",
            font=("Consolas",10,"bold")).grid(
                row=0,column=0,columnspan=5,sticky="ew",padx=8,pady=(7,4))

        tk.Label(
            self.result_inner,
            text="VALUE BASIS: DIVINE ORBS ONLY",
            anchor="w",background="white",
            font=("Segoe UI",9,"bold")).grid(
                row=1,column=0,columnspan=5,sticky="ew",padx=8,pady=(0,4))

        for c,(txt,w) in enumerate(zip(
            ["Rank","Item","Quantity","Divine","Total Divine"],
            [55,330,90,130,145])):
            tk.Label(self.result_inner,text=txt,width=max(8,w//9),
                     anchor="w",background="white",
                     font=("Segoe UI",9,"bold")).grid(
                         row=1,column=c,sticky="ew",padx=3,pady=(2,5))
        self.result_inner.grid_columnconfigure(1,weight=1)

        # Always render exactly 20 result rows. Empty rows are intentionally
        # retained so the table geometry never changes between evaluations.
        display_rows = rows[:20] + [None] * max(0, 20-len(rows))
        for i,r in enumerate(display_rows,1):
            if r is None:
                for c,val in [(0,f"{i}."),(1,""),(2,""),(3,""),(4,"")]:
                    tk.Label(self.result_inner,text=val,anchor="w",
                             background="white",font=("Consolas",10)).grid(
                                 row=i+2,column=c,sticky="w",padx=3,pady=1)
                continue
            unit=r.get("unit_price")
            unit_s=f"{float(unit):.2f}" if unit is not None else "?"
            icon_img=None
            p=r.get("icon_file","")
            if p and os.path.exists(p):
                try:
                    im=Image.open(p).convert("RGBA")
                    im.thumbnail((30,30),Image.Resampling.LANCZOS)
                    icon_img=ImageTk.PhotoImage(im)
                    self.result_images.append(icon_img)
                except Exception:
                    pass

            tk.Label(self.result_inner,text=f"{i}.",anchor="w",
                     background="white",font=("Consolas",10)).grid(
                         row=i+2,column=0,sticky="w",padx=3,pady=1)

            cell=tk.Frame(self.result_inner,background="white")
            cell.grid(row=i+2,column=1,sticky="ew",padx=3,pady=1)
            if icon_img:
                tk.Label(cell,image=icon_img,background="white",
                         width=32,height=32).pack(side="left",padx=(0,7))
            tk.Label(cell,text=r["name"][:42],anchor="w",
                     background="white",font=("Consolas",10)).pack(
                         side="left",fill="x",expand=True)

            for c,val in [(2,str(r["quantity"])),(3,unit_s),(4,f"{r['total_value']:.2f}")]:
                tk.Label(self.result_inner,text=val,anchor="w",
                         background="white",font=("Consolas",10)).grid(
                             row=i+2,column=c,sticky="w",padx=3,pady=1)

        tk.Label(self.result_inner,
            text="Unit price and total value are shown for market-priced items only. Non-unique charms are utility items and are excluded from the value ranking. Prices are from poe.ninja.",
            anchor="w",background="white",
            font=("Segoe UI",9,"italic")).grid(
                row=23,column=0,columnspan=5,sticky="ew",padx=8,pady=(8,8))

        self.safe_json_dump(
            os.path.join(APP,"top20.json"),
            {"league_id":self.league_id,"league_name":self.league_name,
             "tabs":self.session_tab_count,"items":rows[:20],"all_items":rows},
            quiet=True)
        self.result_canvas.yview_moveto(0)
        self.root.after_idle(lambda: self.log.see("end"))
        return rows

    def capture(self):
        if self.scan_running:
            self.status.set("Scan already running – please wait.")
            return
        self.scan_running=True
        self.f8_count += 1
        f8_id=f"{self.evaluation_id}-F8-{self.f8_count:03d}"
        try:
            self.log.insert("end", f"F8 REQUEST v6.29 | id={f8_id}")
            if not self.cfg.get("calibrated",False):
                self.status.set("Zuerst F7 kalibrieren.")
                return

            try:
                league_id,league_name=self.get_current_league()
                global LEAGUE
                LEAGUE=league_id
                self.status.set(f"Aktuelle League: {league_name} – References prüfen …")
                self.root.update()
            except Exception as e:
                self.status.set("Liga konnte nicht ermittelt werden: "+repr(e))
                return

            # Refresh the General reference set automatically when the league changes.
            cached=self.cfg.get("cached_league_id")
            if cached != self.league_id or not self.reference_ready():
                if not self.build_reference_database():
                    return
                self.cfg["cached_league_id"]=self.league_id
                self.safe_json_dump(CONFIG,self.cfg,quiet=False)

            # IMPORTANT: this is the only point where a scan screenshot is captured.
            # F7 calibration also grabs the game window, but never writes to screenshots/.
            # v6.29 retains the hard preflight immediately before F8: every previous
            # screenshot/debug PNG is removed and the folder must be empty.
            # This prevents OneDrive/restarts/old evaluations from being mistaken
            # for the image belonging to the current F8 press.
            preflight_removed=[]
            preflight_errors=[]
            try:
                os.makedirs(SHOT_DIR,exist_ok=True)
                for name in os.listdir(SHOT_DIR):
                    path=os.path.join(SHOT_DIR,name)
                    if os.path.isfile(path) and name.lower().endswith(('.png','.jpg','.jpeg','.webp')):
                        try:
                            os.remove(path)
                            preflight_removed.append(name)
                        except OSError as ex:
                            preflight_errors.append(f"{name}: {ex}")
                remaining=[n for n in os.listdir(SHOT_DIR)
                           if os.path.isfile(os.path.join(SHOT_DIR,n)) and n.lower().endswith(('.png','.jpg','.jpeg','.webp'))]
            except Exception as ex:
                remaining=[]
                preflight_errors.append(repr(ex))

            if preflight_removed:
                self.log.insert("end", f"F8 PREFLIGHT v6.29 | id={f8_id} | {len(preflight_removed)} alte Screenshot-Datei(en) entfernt.")
            else:
                self.log.insert("end", f"F8 PREFLIGHT v6.29 | id={f8_id} | Screenshot-Ordner war bereits leer.")
            if preflight_errors or remaining:
                detail="; ".join(preflight_errors + [f"nicht entfernbar: {n}" for n in remaining])
                self.log.insert("end", f"F8 CAPTURE ABORTED v6.29 | id={f8_id} | Screenshot-Ordner konnte nicht geleert werden: {detail}")
                self.status.set("F8 abgebrochen: alte Screenshot-Dateien konnten nicht sicher entfernt werden.")
                return

            f8_started=time.time()
            self.log.insert("end", f"F8 CAPTURE START v6.29 | id={f8_id} | {time.strftime('%H:%M:%S',time.localtime(f8_started))}")
            self.root.update()
            img=self.grab()
            if img is None:
                self.log.insert("end", "F8 CAPTURE ABORTED: PoE2 window not found; no screenshot written.")
                return

            iw,ih=img.size
            x1=round(iw*self.cfg["left"]); y1=round(ih*self.cfg["top"])
            x2=round(iw*self.cfg["right"]); y2=round(ih*self.cfg["bottom"])
            stash=img.crop((x1,y1,x2,y2))

            import hashlib as _hashlib
            stash_hash=_hashlib.sha1(stash.tobytes()).hexdigest()
            if stash_hash in self.session_hashes:
                self.status.set("Dieser Tab wurde in dieser Auswertung bereits erfasst – ignoriert.")
                return
            self.session_hashes.add(stash_hash)
            self.session_tab_count += 1

            stash_path=os.path.join(SHOT_DIR,f"stash_{self.counter:03d}.png")
            debug_path=os.path.join(SHOT_DIR,f"icons_{self.counter:03d}.png")

            # Save and immediately verify the files. If Windows/OneDrive or a
            # stale process prevents the write, the scan stops instead of
            # silently continuing with an old image.
            stash.save(stash_path)
            if not os.path.isfile(stash_path):
                raise RuntimeError(f"F8 screenshot was not written: {stash_path}")
            stash_mtime=os.path.getmtime(stash_path)
            if stash_mtime + 1 < f8_started:
                raise RuntimeError(f"F8 screenshot timestamp is stale: {stash_path}")

            debug,data,folder=self.analyze(stash)
            debug.save(debug_path)
            if not os.path.isfile(debug_path):
                raise RuntimeError(f"F8 debug screenshot was not written: {debug_path}")
            debug_mtime=os.path.getmtime(debug_path)
            if debug_mtime + 1 < f8_started:
                raise RuntimeError(f"F8 debug screenshot timestamp is stale: {debug_path}")

            # v6.29: keep the exact two files belonging to the latest F8 scan.
            self.last_stash_path=stash_path
            self.last_debug_path=debug_path

            self.log.insert(
                "end",
                f"F8 CAPTURE VERIFIED v6.29 | id={f8_id} | stash={stash_path} mtime={time.strftime('%H:%M:%S',time.localtime(stash_mtime))}; "
                f"debug={debug_path} mtime={time.strftime('%H:%M:%S',time.localtime(debug_mtime))}"
            )

            try:
                with open(os.path.join(folder,"manifest.json"),encoding="utf-8") as f:
                    manifest=json.load(f)
                icons=manifest.get("icons",[])
            except Exception:
                icons=[]

            matches=self.identify_icons(folder,icons)
            self.safe_json_dump(os.path.join(folder,"matches.json"),matches,quiet=True)

            occ=[x for x in data if x[2]]
            try:
                self.log.insert("end", f"POST-MATCH v6.29: matches={len(matches)} icons={len(icons)} occupied={len(occ)}")
                self.add_matches_to_session(matches,icons)
            except Exception as exc:
                self.log.insert("end", f"POST-MATCH ERROR v5.83: {exc!r}")
                raise
            self.render_top20()

            self.status.set(
                f"Tab {self.session_tab_count} erfasst: {len(occ)} occupied slots. "
                "Open the next tab and press F8 – or start a NEW EVALUATION."
            )
            self.show(debug)
            self.counter+=1
        except Exception as exc:
            # Never fail silently: show the exact stage/error in the GUI log.
            try:
                self.log.insert("end", f"SCAN ERROR v6.29: {type(exc).__name__}: {exc!r}")
                self.log.see("end")
                self.status.set(f"Scanfehler: {type(exc).__name__}: {exc}")
                self.root.update()
            except Exception:
                pass
        finally:
            self.scan_running=False
            self.root.update_idletasks()


    def _clipboard_file_drop(self, paths):
        """Put Windows file paths on the clipboard as CF_HDROP.

        Browsers such as ChatGPT can consume this as file paste, so Ctrl+V
        can attach both PNGs at once instead of requiring manual file picking.
        """
        paths=[os.path.abspath(x) for x in paths if x and os.path.isfile(x)]
        if not paths:
            raise RuntimeError("Keine gültigen Screenshot-Dateien vorhanden.")
        if os.name != "nt":
            raise RuntimeError("Datei-Clipboard ist nur unter Windows verfügbar.")

        class POINT(ctypes.Structure):
            _fields_=[("x",ctypes.c_long),("y",ctypes.c_long)]
        class DROPFILES(ctypes.Structure):
            _fields_=[
                ("pFiles",ctypes.wintypes.DWORD),
                ("pt",POINT),
                ("fNC",ctypes.wintypes.BOOL),
                ("fWide",ctypes.wintypes.BOOL),
            ]

        header=DROPFILES()
        header.pFiles=ctypes.sizeof(DROPFILES)
        header.pt=POINT(0,0)
        header.fNC=False
        header.fWide=True
        payload="\0".join(paths)+"\0\0"
        raw=bytes(header)+payload.encode("utf-16le")
        GMEM_MOVEABLE=0x0002
        CF_HDROP=15
        h=ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVEABLE,len(raw))
        if not h:
            raise RuntimeError("GlobalAlloc für Clipboard fehlgeschlagen.")
        locked=ctypes.windll.kernel32.GlobalLock(h)
        if not locked:
            ctypes.windll.kernel32.GlobalFree(h)
            raise RuntimeError("GlobalLock für Clipboard fehlgeschlagen.")
        try:
            ctypes.memmove(locked,raw,len(raw))
        finally:
            ctypes.windll.kernel32.GlobalUnlock(h)

        if not ctypes.windll.user32.OpenClipboard(self.root.winfo_id()):
            ctypes.windll.kernel32.GlobalFree(h)
            raise RuntimeError("Windows-Clipboard konnte nicht geöffnet werden.")
        try:
            if not ctypes.windll.user32.EmptyClipboard():
                ctypes.windll.kernel32.GlobalFree(h)
                raise RuntimeError("Clipboard konnte nicht geleert werden.")
            if not ctypes.windll.user32.SetClipboardData(CF_HDROP,h):
                ctypes.windll.kernel32.GlobalFree(h)
                raise RuntimeError("CF_HDROP konnte nicht gesetzt werden.")
            h=None  # ownership transferred to Windows
        finally:
            ctypes.windll.user32.CloseClipboard()

    def _build_report_text(self):
        rows=[]
        for rec in self.session_items.values():
            if rec.get("price_exempt"):
                continue
            try:
                unit=float(rec.get("unit_price") or 0)
                total=unit*rec.get("quantity",1)
            except Exception:
                unit=0; total=0
            rows.append((total,rec.get("name","?"),rec.get("quantity",1),unit))
        rows.sort(reverse=True,key=lambda x:x[0])
        lines=[
            f"POE2 TOP 20 – v6.29",
            f"League: {self.league_name or '-'}",
            f"Evaluation: {self.evaluation_id}",
            f"Tabs: {self.session_tab_count}",
            f"Unique items: {len(self.session_items)}",
            "",
            "TOP 20",
            "Rank | Item | Quantity | Divine | Total Divine",
        ]
        for i,(total,name,qty,unit) in enumerate(rows[:20],1):
            lines.append(f"{i:>2} | {name} | {qty} | {unit:.2f} | {total:.2f}")
        if not rows:
            lines.append("(noch keine Werte)")
        lines += [
            "",
            f"Latest stash screenshot: {self.last_stash_path or '-'}",
            f"Latest debug screenshot: {self.last_debug_path or '-'}",
            f"Diagnostic log: {DIAG_LOG}",
        ]
        return "\n".join(lines)

    def _clipboard_image(self, image):
        """Put a PIL image on the Windows clipboard as real PNG + CF_DIB.

        v6.29: browsers such as ChatGPT are much more reliable when the
        clipboard contains an actual ``image/png`` payload.  CF_DIB is kept
        as a compatibility fallback for Windows applications that do not
        request the registered PNG format.
        """
        if os.name != "nt":
            raise RuntimeError("Bild-Clipboard ist nur unter Windows verfügbar.")

        image=image.convert("RGB")

        # PNG payload: this is the important format for browser paste.
        png_io=io.BytesIO()
        image.save(png_io,format="PNG",optimize=True)
        png_bytes=png_io.getvalue()

        # Windows native DIB fallback.
        bmp_io=io.BytesIO()
        image.save(bmp_io,format="BMP")
        dib=bmp_io.getvalue()[14:]

        GMEM_MOVEABLE=0x0002
        CF_DIB=8
        CF_PNG=ctypes.windll.user32.RegisterClipboardFormatW("PNG")
        if not CF_PNG:
            raise RuntimeError("Windows konnte das PNG-Clipboard-Format nicht registrieren.")

        def alloc_bytes(data, label):
            h=ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVEABLE,len(data))
            if not h:
                raise RuntimeError(f"GlobalAlloc für {label} fehlgeschlagen.")
            locked=ctypes.windll.kernel32.GlobalLock(h)
            if not locked:
                ctypes.windll.kernel32.GlobalFree(h)
                raise RuntimeError(f"GlobalLock für {label} fehlgeschlagen.")
            try:
                ctypes.memmove(locked,data,len(data))
            finally:
                ctypes.windll.kernel32.GlobalUnlock(h)
            return h

        h_png=alloc_bytes(png_bytes,"PNG-Clipboard")
        h_dib=alloc_bytes(dib,"DIB-Clipboard")

        if not ctypes.windll.user32.OpenClipboard(self.root.winfo_id()):
            ctypes.windll.kernel32.GlobalFree(h_png)
            ctypes.windll.kernel32.GlobalFree(h_dib)
            raise RuntimeError("Windows-Clipboard konnte nicht geöffnet werden.")

        try:
            if not ctypes.windll.user32.EmptyClipboard():
                ctypes.windll.kernel32.GlobalFree(h_png)
                ctypes.windll.kernel32.GlobalFree(h_dib)
                raise RuntimeError("Clipboard konnte nicht geleert werden.")

            # Register both representations. Browser clients can request
            # image/png; native Windows programs can fall back to CF_DIB.
            if not ctypes.windll.user32.SetClipboardData(CF_PNG,h_png):
                ctypes.windll.kernel32.GlobalFree(h_png)
                h_png=None
                ctypes.windll.kernel32.GlobalFree(h_dib)
                h_dib=None
                raise RuntimeError("PNG-Clipboard konnte nicht gesetzt werden.")
            h_png=None  # ownership transferred to Windows

            if not ctypes.windll.user32.SetClipboardData(CF_DIB,h_dib):
                ctypes.windll.kernel32.GlobalFree(h_dib)
                h_dib=None
                raise RuntimeError("CF_DIB konnte nicht gesetzt werden.")
            h_dib=None  # ownership transferred to Windows
        finally:
            # Any handle still owned by us must be released.
            if h_png:
                ctypes.windll.kernel32.GlobalFree(h_png)
            if h_dib:
                ctypes.windll.kernel32.GlobalFree(h_dib)
            ctypes.windll.user32.CloseClipboard()

    def copy_stash_screenshot(self):
        try:
            if not self.last_stash_path or not os.path.isfile(self.last_stash_path):
                raise RuntimeError("Noch kein vollständiger F8-Scan vorhanden.")
            with Image.open(self.last_stash_path) as im:
                self._clipboard_image(im.copy())
            self.status.set("Stash-Screenshot kopiert – hier mit Strg+V einfügen.")
            self.log.insert("end", "CLIPBOARD v6.29: stash screenshot als echtes Bild kopiert.")
        except Exception as exc:
            self.status.set(f"Clipboard-Fehler: {exc}")
            self.log.insert("end", f"CLIPBOARD ERROR v6.29 stash: {exc!r}")

    def copy_debug_screenshot(self):
        try:
            if not self.last_debug_path or not os.path.isfile(self.last_debug_path):
                raise RuntimeError("Noch kein vollständiger F8-Scan vorhanden.")
            with Image.open(self.last_debug_path) as im:
                self._clipboard_image(im.copy())
            self.status.set("Debug-Screenshot kopiert – hier mit Strg+V einfügen.")
            self.log.insert("end", "CLIPBOARD v6.29: debug screenshot als echtes Bild kopiert.")
        except Exception as exc:
            self.status.set(f"Clipboard-Fehler: {exc}")
            self.log.insert("end", f"CLIPBOARD ERROR v6.29 debug: {exc!r}")

    def copy_two_screenshots(self):
        """Create one PNG containing the two latest screenshots and copy it.

        The combined PNG is also written to the screenshots folder. If the
        browser does not accept the Windows image clipboard, Explorer opens
        with the PNG selected so it can be dragged into the chat directly.
        """
        try:
            if not self.last_stash_path or not self.last_debug_path:
                raise RuntimeError("Noch kein vollständiger F8-Scan vorhanden.")
            stash=Image.open(self.last_stash_path).convert("RGB")
            debug=Image.open(self.last_debug_path).convert("RGB")
            width=max(stash.width,debug.width)
            separator=8
            combined=Image.new("RGB",(width,stash.height+separator+debug.height),(255,255,255))
            combined.paste(stash,((width-stash.width)//2,0))
            combined.paste(debug,((width-debug.width)//2,stash.height+separator))
            out=os.path.join(SHOT_DIR,"screenshots_latest_bundle.png")
            combined.save(out,format="PNG",optimize=True)
            try:
                self._clipboard_image(combined)
                self.status.set("2 Screenshots als ein Bild kopiert – hier mit Strg+V einfügen. Datei liegt zusätzlich als screenshots_latest_bundle.png vor.")
            except Exception as clip_exc:
                self.status.set("Clipboard nicht angenommen. Die Bilddatei wurde erzeugt und im Explorer markiert.")
                if os.name == "nt":
                    subprocess.Popen(["explorer.exe", "/select,", os.path.normpath(out)])
                self.log.insert("end", f"CLIPBOARD FALLBACK v6.29: {clip_exc!r}; Datei={out}")
                return
            self.log.insert("end", f"CLIPBOARD v6.29: 2 Screenshots als PNG kopiert; Datei={out}")
        except Exception as exc:
            self.status.set(f"Screenshot-Fehler: {exc}")
            self.log.insert("end", f"SCREENSHOT COPY ERROR v6.29: {exc!r}")

    def _build_bundle_image(self):
        """Create one paste-ready image containing report + both screenshots.

        A browser clipboard can reliably paste one image into ChatGPT, while
        multi-file/CF_HDROP pastes are not consistently exposed to the browser.
        The bundle therefore keeps the three artifacts together without
        changing the original PNGs.
        """
        if not self.last_stash_path or not self.last_debug_path:
            raise RuntimeError("Noch kein vollständiger F8-Scan vorhanden.")
        if not os.path.isfile(self.last_stash_path) or not os.path.isfile(self.last_debug_path):
            raise RuntimeError("Die letzten Screenshot-Dateien wurden nicht gefunden.")

        report=self._build_report_text()
        report_path=os.path.join(SHOT_DIR,"report_latest.txt")
        try:
            with open(report_path,"w",encoding="utf-8") as f:
                f.write(report)
        except Exception:
            report_path=None

        with Image.open(self.last_stash_path) as sim:
            stash=sim.convert("RGB")
        with Image.open(self.last_debug_path) as dim:
            debug=dim.convert("RGB")

        # Use a readable report header. The screenshots stay at native size.
        width=max(stash.width,debug.width,1200)
        try:
            from PIL import ImageFont
            font=ImageFont.truetype("consola.ttf",16)
            small=ImageFont.truetype("consola.ttf",14)
            bold=ImageFont.truetype("consolab.ttf",18)
        except Exception:
            from PIL import ImageFont
            font=ImageFont.load_default()
            small=font
            bold=font

        # Wrap report only at very long lines so the item table remains intact.
        report_lines=[]
        for line in report.splitlines():
            if len(line) <= 115:
                report_lines.append(line)
            else:
                while len(line) > 115:
                    report_lines.append(line[:115])
                    line=line[115:]
                if line:
                    report_lines.append(line)
        line_h=22 if getattr(font,'size',16)>=16 else 14
        report_h=72 + max(1,len(report_lines))*line_h
        gap=12
        total_h=report_h + gap + stash.height + gap + debug.height
        canvas=Image.new("RGB",(width,total_h),(245,245,245))
        draw=ImageDraw.Draw(canvas)
        draw.text((24,18),"POE2 TOP20 – COPY BUNDLE",font=bold,fill=(0,0,0))
        y=48
        for line in report_lines:
            draw.text((24,y),line,font=font,fill=(0,0,0))
            y+=line_h

        # Also persist the report itself as PNG so the local output folder
        # contains the same image-oriented artifacts that are used for paste.
        report_png_path=os.path.join(SHOT_DIR,"report_latest.png")
        try:
            canvas.crop((0,0,width,report_h)).save(report_png_path,format="PNG",optimize=True)
        except Exception as exc:
            self.log.insert("end",f"REPORT PNG ERROR v6.29: {exc!r}")

        y=report_h
        draw.rectangle((0,y,width,y+gap),fill=(210,210,210))
        y+=gap
        canvas.paste(stash,((width-stash.width)//2,y))
        y+=stash.height
        draw.rectangle((0,y,width,y+gap),fill=(210,210,210))
        y+=gap
        canvas.paste(debug,((width-debug.width)//2,y))
        return canvas,report_path

    def copy_all_bundle(self):
        try:
            bundle,report_path=self._build_bundle_image()
            self._clipboard_image(bundle)
            self.status.set("Report + beide Screenshots kopiert – jetzt hier mit Strg+V einfügen.")
            self.log.insert("end",
                "CLIPBOARD v6.29: Report + stash_*.png + icons_*.png als ein Bild (PNG + CF_DIB) kopiert."
                + (f" Report-Datei: {report_path}" if report_path else ""))
        except Exception as exc:
            self.status.set(f"Clipboard-Fehler: {exc}")
            self.log.insert("end", f"CLIPBOARD ERROR v6.29 bundle: {exc!r}")

    def copy_report(self):
        try:
            report=self._build_report_text()
            self.root.clipboard_clear()
            self.root.clipboard_append(report)
            self.root.update()
            self.status.set("Report kopiert – jetzt hier mit Strg+V einfügen.")
            self.log.insert("end", "REPORT CLIPBOARD v6.29: Textreport kopiert.")
        except Exception as exc:
            self.status.set(f"Report konnte nicht kopiert werden: {exc}")
            self.log.insert("end", f"REPORT CLIPBOARD ERROR v6.29: {exc!r}")

    def show(self,img):
        win=tk.Toplevel(self.root);win.title("PoE2 Top20 – Scan")
        w,h=img.size;s=min(1,1050/w,780/h)
        if s<1:img=img.resize((int(w*s),int(h*s)),Image.Resampling.LANCZOS)
        ph=ImageTk.PhotoImage(img);win._ph=ph;tk.Label(win,image=ph).pack()
        tk.Label(win,text="Grün=belegt | Rot=leer | ?=Mengenbereich erkannt | ESC=schließen").pack(pady=4)
        win.bind("<Escape>",lambda e:win.destroy())

    def show_contact_sheet(self,folder):
        path=os.path.join(folder,"icon_contact_sheet.png")
        if not os.path.exists(path):
            return
        img=Image.open(path)
        win=tk.Toplevel(self.root)
        win.title("PoE2 Top20 – erkannte Icons")
        win.attributes("-topmost",True)
        w,h=img.size
        s=min(1,1100/w,800/h)
        if s<1:
            img=img.resize((int(w*s),int(h*s)),Image.Resampling.LANCZOS)
        ph=ImageTk.PhotoImage(img)
        win._ph=ph
        tk.Label(win,image=ph).pack()
        tk.Label(
            win,
            text="Jedes Feld zeigt das zentrale Icon des belegten Slots. ESC = schließen"
        ).pack(pady=4)
        win.bind("<Escape>",lambda e:win.destroy())

    def open_config(self):
        try:os.startfile(CONFIG)
        except Exception as e:messagebox.showerror("config.json",str(e))

    def poll_keys(self):
        for vk,fn in [(VK_F7,self.start_calibration),(VK_F8,self.capture)]:
            down=bool(u.GetAsyncKeyState(vk)&0x8000)
            if not down:
                self.key_armed[vk]=True
                self.old[vk]=False
                continue
            if self.key_armed[vk] and not self.scan_running:
                self.key_armed[vk]=False
                self.old[vk]=True
                try:
                    fn()
                except Exception as ex:
                    self.status.set(f"Action failed: {type(ex).__name__}: {ex}")
                    self.log.insert("end",f"Action failed: {ex!r}")
        self.root.after(30,self.poll_keys)


    def close(self):self.root.destroy()

if __name__=="__main__":App()
