POE2 TOP20 v6.28

Änderungen:
- Itemerkennung: Rune-Familien bleiben nach tatsächlichen poe.ninja-Stufen getrennt.
- Inspiration Rune: sechs bestätigte Slot-Referenzen aus dem bisherigen Testlauf wurden als überwachte Seeds ergänzt (Lesser/Normal/Greater). Die Seeds greifen nur bei denselben Slots und nur bei ausreichender visueller Übereinstimmung.
- Mengen/OCR: unverändert.
- Bedienung: die vier bisherigen COPY-Buttons wurden zu einem Button zusammengefasst: COPY REPORT + 2 SCREENSHOTS.
- Dieser Button erzeugt ein einziges pastebares Bild mit Report, Stash-Screenshot und Debug-Screenshot. Zusätzlich wird report_latest.txt im screenshots-Ordner abgelegt.
- Original-Screenshots bleiben unverändert.
- ZIP enthält keinen zusätzlichen übergeordneten Ordner.
