PoE2 Top20 v6.28

Diese Version trennt Itemerkennung und Mengenlogik weiterhin strikt.
Die Rune-Erkennung wurde für echte Upgrade-Familien verbessert. Für die im aktuellen Testlauf eindeutig bekannten Inspiration-Rune-Slots sind sechs überwachte Referenzen enthalten; sie gelten nur slotbezogen und werden nur bei ausreichender visueller Übereinstimmung verwendet.

Der bisherige 4-fache Copy-Bereich wurde durch einen einzigen Button ersetzt:
COPY REPORT + 2 SCREENSHOTS

Ein Klick erzeugt ein einziges Bild für Strg+V nach ChatGPT. Es enthält:
1. den aktuellen Textreport,
2. den Stash-Screenshot,
3. den Debug-Screenshot.

Die Originalbilder bleiben im screenshots-Ordner erhalten.
