import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

APP = os.path.dirname(os.path.abspath(__file__))
LOCAL_VERSION_FILE = os.path.join(APP, "version.json")

VERSION_URL = "https://raw.githubusercontent.com/Homer99-S/Homer/main/version.json"
GITHUB_RAW_BASE = "https://raw.githubusercontent.com/Homer99-S/Homer/main/"

def read_local_version():
    try:
        with open(LOCAL_VERSION_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return str(data.get("version", "0"))
    except Exception:
        return "0"

def version_tuple(value):
    try:
        return tuple(int(x) for x in str(value).strip().lstrip("v").split("."))
    except Exception:
        return (0,)

def get_remote_info():
    req = urllib.request.Request(
        VERSION_URL,
        headers={"User-Agent": "PoE2-Top20-Updater"}
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))

def download_file(url, target):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "PoE2-Top20-Updater"}
    )
    with urllib.request.urlopen(req, timeout=60) as r, open(target, "wb") as f:
        shutil.copyfileobj(r, f)

def update_from_zip(package_url):
    with tempfile.TemporaryDirectory(prefix="poe2_update_") as tmp:
        zip_path = os.path.join(tmp, "update.zip")
        extract_dir = os.path.join(tmp, "extract")
        os.makedirs(extract_dir)

        print("Neue Version wird heruntergeladen ...")
        download_file(package_url, zip_path)

        with zipfile.ZipFile(zip_path) as z:
            z.extractall(extract_dir)

        # Keep the updater itself stable while updating the application files.
        for root, dirs, files in os.walk(extract_dir):
            rel_root = os.path.relpath(root, extract_dir)
            dest_root = APP if rel_root == "." else os.path.join(APP, rel_root)
            os.makedirs(dest_root, exist_ok=True)

            for filename in files:
                if filename.lower() == "updater.py":
                    continue
                src = os.path.join(root, filename)
                dst = os.path.join(dest_root, filename)
                os.replace(src, dst)

def main():
    local_version = read_local_version()
    print(f"Lokale Version: {local_version}")

    try:
        remote = get_remote_info()
        remote_version = str(remote.get("version", "0"))
        package = str(remote.get("package", "")).strip()

        print(f"GitHub-Version: {remote_version}")

        if version_tuple(remote_version) <= version_tuple(local_version):
            print("Keine Aktualisierung erforderlich.")
        elif not package:
            print("Neue Version gefunden, aber kein Paket angegeben.")
        else:
            package_url = GITHUB_RAW_BASE + package
            update_from_zip(package_url)
            print(f"Update auf Version {remote_version} abgeschlossen.")
    except Exception as exc:
        # An update failure must never prevent the existing overlay from starting.
        print(f"Update-Prüfung fehlgeschlagen: {exc}")

    overlay = os.path.join(APP, "overlay.py")
    subprocess.Popen([sys.executable, overlay], cwd=APP)

if __name__ == "__main__":
    main()
